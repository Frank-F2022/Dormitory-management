package GUI;

import javax.swing.*;

public class AddRoomFailedGUI {
    JFrame jFrame = new JFrame("房间信息添加失败");
    public AddRoomFailedGUI() {
        //实例化一个JDialog类对象，指定对话框的父窗体、窗体标题和类型
        //super(frame, "JDialog窗体", true);
        jFrame.setBounds(500,200,350, 150);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        // container = getContentPane();                    //创建一个容器
        jFrame.add(new JLabel("<html>已存在对应楼号和房间号的房间或者不存在对应楼号<br>" +
                "如果房间已存在，表格将生成该房间的信息<br>请关闭该窗口以重新输入</html>",JLabel.CENTER));  //在容器中添加标签
        //moji.setBounds(120, 120, 150, 100);          //设置对话框窗体大小
    }
}
