package GUI;

import javax.swing.*;
import java.awt.event.*;

//选择功能界面，选择查找，管理，登出，退出。
public class RootGUI {
    //初始化变量
    JFrame jFrame = new JFrame("管理员功能选择");
    JPanel pp = new JPanel();
    JButton search = new JButton("查找");
    JButton bSwitch = new JButton("学生分配或调换宿舍");
    JButton bManage = new JButton("管理");
    JButton logout = new JButton("登出");
    JButton exit = new JButton("退出");
    public static boolean isSearch = false;
    public static boolean isSwitch = false;
    public static boolean isManage = false;
    public static boolean isLogout = false;
    public static boolean isExit = false;
    public static boolean isListened = false;

    public RootGUI() {
        //实例化一个JDialog类对象，指定对话框的父窗体、窗体标题和类型
        //super(frame, "JDialog窗体", true);
        jFrame.setBounds(500,200,550, 320);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // ll.setIcon(icon);
        //  ll.setBounds(0, 0, icon.getIconWidth(), icon.getIconHeight()); // 设置组件的显示位置及大小
        //aa.getContentPane().add(ll);
        pp.setLayout(null);
        jFrame.add(pp);

        search.setBounds(200,20,150,25);
        bSwitch.setBounds(200 ,60,150,25);
        bManage.setBounds(200,100,150,25);

        logout.setBounds(450,200,60,25);
        exit.setBounds(450,240,60,25);

        pp.add(search);
        pp.add(bSwitch);pp.add(bManage);

        pp.add(logout);
        pp.add(exit);

        search.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                isSearch = true;
                isListened = true;
            }
        });
        bSwitch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                isSwitch = true;
                isListened = true;
            }
        });
        bManage.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                isManage = true;
                isListened = true;
            }
        });
        logout.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jFrame.dispose();
                isLogout = true;
                isListened = true;
            }
        });
        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jFrame.dispose();
                isExit = true;
                isListened = true;
            }
        });
    }

    public boolean isListened(){
        return isListened;
    }

    public void init(){
        isSearch = false;
        isSwitch = false;
        isManage = false;
        isLogout = false;
        isExit = false;
        isListened = false;
    }

    public void close(){
        jFrame.dispose();
    }

    public static void main(String[] args){
        new RootGUI();
    }
}

