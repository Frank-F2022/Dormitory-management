package GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginGUI {

    //初始化变量
    public JFrame jframe = new JFrame("登录 ");
    JLabel userLabel = new JLabel("用户名");
    JTextField userText = new JTextField(20);
    JLabel passwordLabel = new JLabel("密码");
    JPasswordField passwordText = new JPasswordField(20);
    JButton loginButton = new JButton("登录");
//    JButton registerButton = new JButton("register");
    JPanel panel = new JPanel();
    JButton inf = new JButton("i");
    Font Fonts = new Font("行书", Font.BOLD, 15);
    Font f1 = new Font("行书", Font.PLAIN, 10);
    public static int userTextInput = -1;
    public static String passwordTextInput = null;
    public static boolean isListened = false;
    public LoginGUI(){
        //初始化界面
        jframe.setBounds(500,200,300, 200);
        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jframe.setVisible(true);
        jframe.setResizable(false);

        //添加面板panel
        jframe.add(panel);
        panel.setLayout(null);

        //添加登录按钮并设置其字体、颜色等参数
        inf.setFont(f1);
        loginButton.setBounds(145, 80, 80, 25);
        panel.add(loginButton);
        loginButton.setFont(Fonts);
        inf.setBounds(260,145,10,10);
        inf.setMargin(new Insets(0,0,0,0));
        inf.setBorder(BorderFactory.createRaisedBevelBorder());
        inf.setBackground(Color.YELLOW);
        panel.add(inf);

        //添加用户标签和密码标签
        userLabel.setBounds(10,20,40,25);
        panel.add(userLabel);
        passwordLabel.setBounds(10,50,40,25);
        panel.add(passwordLabel);

        //添加用户文本框和密码文本框
        userText.setBounds(60,20,165,25);
        panel.add(userText);
        passwordText.setBounds(60,50,165,25);
        panel.add(passwordText);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                userTextInput = Integer.parseInt(userText.getText());
                passwordTextInput = passwordText.getText();
            }
        });

        inf.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(panel,"本程序作者：\n傅泓铭、毛楷贺、邵一辰、范治辰、刘帝亨");
            }
        });
    }

    public boolean isLogin(){
        isListened = false;
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                userTextInput = Integer.parseInt(userText.getText());
                passwordTextInput = passwordText.getText();
                isListened = true;
            }
        });
        return isListened;
    }

    public void LoginGUIClose(){
        jframe.dispose();
    }

    public static void main(String[] args){
        new LoginGUI();
    }
}
