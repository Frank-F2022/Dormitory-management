package GUI;

import user.Root;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class DeleteBuildingGUI {
    JFrame a=new JFrame("删除宿舍楼");
    JPanel p11=new JPanel();

    JLabel j1=new JLabel("要删除的宿舍楼ID");
    JTextField buildingID=new JTextField(15);
    JButton yes =new JButton("确认");

    public static boolean isClosing = false;
    public static boolean isListened = false;
    int buildingid;
    public DeleteBuildingGUI(){
        a.setBounds(550,250,370, 180);
        a.setVisible(true);
        a.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        p11.setLayout(null);
        a.add(p11);
        j1.setBounds(30,50,140,25);
        buildingID.setBounds(140,50,100,25);
        yes.setBounds(250,50,80,25);
        p11.add(j1);
        p11.add(buildingID);
        p11.add(yes);

        yes.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buildingid = Integer.parseInt(buildingID.getText());
                isListened = true;
            }
        });
        a.addWindowListener(new WindowListener(){
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
//                jFrame.dispose();
                isClosing = true;
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });
    }

    public void init(){
        isListened = false;
        isClosing = false;
    }

    public boolean isListened(){
        return isListened;
    }

    public boolean isClosing(){
        return isClosing;
    }

    public void delete() {
        Root r = new Root();
        r.deleteBuilding(buildingid);
    }

    public static void main(String[] args){
        new DeleteBuildingGUI();
    }
}
