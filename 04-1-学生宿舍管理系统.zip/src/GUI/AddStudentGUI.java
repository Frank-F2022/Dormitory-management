package GUI;

import user.Root;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.sql.ResultSet;
import java.util.Vector;

//新增学生 信息输入界面
public class AddStudentGUI {
    JFrame a=new JFrame("新增学生");
    JPanel p10=new JPanel();
    JLabel j1=new JLabel("学生ID");
    JLabel j2=new JLabel("学生姓名");
    JLabel j3=new JLabel("性别(M.男F.女)");
    JLabel j4=new JLabel("学生专业");
    JLabel j5=new JLabel("学生年级");
    JLabel j6=new JLabel("电话号码");
    JLabel j7=new JLabel("学生学院");
    JTextField studentid=new JTextField(15);
    JTextField studentname=new JTextField(15);
    JTextField studentmajor=new JTextField(15);
    JTextField studentdept=new JTextField(15);
    JTextField studentgender=new JTextField(15);
    JTextField studentgrade=new JTextField(15);
    JTextField studentphone=new JTextField(15);
    JButton yes =new JButton("确认");
    public static boolean isClosing = false;
    public static boolean isListened = false;
    String[] titleStudent = {"学生ID","姓名","性别","学院","专业","手机号码","年级"};
    String[][] data = {};
    DefaultTableModel defaultTableModel;
    JTable jTable;
    JScrollPane jsp;
    int sid;
    String sname;
    String smajor;
    char sgender;
    String sdept;
    String sgrade;
    String sphone;
    public AddStudentGUI(){
        a.setBounds(550,250,700, 400);
        a.setVisible(true);
        a.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        p10.setLayout(null);
        a.add(p10);

        j1.setBounds(10,10,50,25);
        j2.setBounds(180,10,50,25);
        j3.setBounds(340,10,90,25);
        j4.setBounds(10,40,50,25);
        j5.setBounds(180,40,50,25);
        j6.setBounds(340,40,100,25);
        j7.setBounds(530,10,50,25);

        studentid.setBounds(90,10,80,25);
        studentname.setBounds(250,10,80,25);
        studentgender.setBounds(440,10,80,25);
        studentdept.setBounds(590,10,80,25);
        studentmajor.setBounds(90,40,80,25);
        studentgrade.setBounds(250,40,80,25);
        studentphone.setBounds(400,40,120,25);

        yes.setBounds(590,40,80,25);

        p10.add(j1);p10.add(j2);p10.add(j3);p10.add(j4);p10.add(j5);p10.add(j6);p10.add(j7);
        p10.add(studentid);p10.add(studentname);p10.add(studentgender);
        p10.add(studentmajor);p10.add(studentdept);
        p10.add(studentgrade);p10.add(studentphone);
        p10.add(yes);

        yes.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sid = Integer.parseInt(studentid.getText());
                sname = studentname.getText();
                sgender = studentgender.getText().charAt(0);
                sdept = studentdept.getText();
                smajor = studentmajor.getText();
                sgrade = studentgrade.getText();
                sphone = studentphone.getText();
                if(studentgender.getText().charAt(0) != 'M' && studentgender.getText().charAt(0) != 'F'){
                    new InvalidGenderGUI();
                    isListened = false;
                    return;
                }else if(!studentgrade.getText().matches("^20\\d{2}$")){
                    new InvalidGradeGUI();
                    isListened = false;
                    return;
                }else if(!studentid.getText().substring(0,4).matches(studentgrade.getText()) || studentid.getText().length() != 7){
                    new InvalidStudentIDGUI();
                    isListened = false;
                    return;
                }else if(!studentphone.getText().matches("^1[3456789]\\d{9}$")){
                    new InvalidPhoneNumberGUI();
                    isListened = false;
                    return;
                }
                isListened = true;
            }
        });
        a.addWindowListener(new WindowListener(){
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
//                jFrame.dispose();
                isClosing = true;
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });
    }

    public int getSid() {
        return sid;
    }

    public void init(){
        isListened = false;
        isClosing = false;
    }

    public boolean isListened(){
        return isListened;
    }

    public boolean isClosing(){
        return isClosing;
    }

    public void clearTable(){
        defaultTableModel.getDataVector().clear();
        jTable.clearSelection();
        a.remove(jsp);
//        jsp.setColumnHeader(null);
    }

    public void showStudentTable(ResultSet rs){
        defaultTableModel = new DefaultTableModel(data,titleStudent);
        jTable = new JTable(defaultTableModel);
        jTable.setPreferredScrollableViewportSize(new Dimension(550, 300));
        jTable.setRowHeight(20);
        jTable.setBounds(10,80,550,300);

        jsp = new JScrollPane(jTable);
        jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        jsp.setBounds(10,80,650,300);
        jsp.setWheelScrollingEnabled(false);
//        System.out.println(jsp.isWheelScrollingEnabled());
        a.add(jsp);

        try{
            do{
                Vector<String> vector = new Vector<String>();
                vector.addElement(rs.getString(1));
                vector.addElement(rs.getString(2));
                vector.addElement(rs.getString(3));
                vector.addElement(rs.getString(4));
                vector.addElement(rs.getString(5));
                vector.addElement(rs.getString(6));
                vector.addElement(rs.getString(7));
                defaultTableModel.addRow(vector);
            }while(rs.next());
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void showResult() {
        Root r = new Root();
        r.addStu(sid,sname,sgender,sdept,smajor,sgrade,sphone);
        showStudentTable(r.findRoom_byStudentID3(this.getSid()));
    }

//    public static void main(String[] args){
//       AddStudentGUI a = new AddStudentGUI();
//       a.showResultTest(2021001);
//    }
}
