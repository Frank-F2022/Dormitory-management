package GUI;

import user.Viewer;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.util.Vector;

public class SwitchStudentGUI {
    JFrame jFrame = new JFrame("宿舍新增或调换学生");
    JPanel jPanel = new JPanel();
    JLabel lableStudentID = new JLabel("学生ID");
    JLabel lableHouseID = new JLabel("调入宿舍楼ID");
    JLabel lableRoomID = new JLabel("房间号ID");
    JLabel lableBedID = new JLabel("床号");
    JLabel result = new JLabel("调换有2个结果，调换前在上，调换后在下，没有对应学生或学生未分配宿舍则不显示结果；新分配只有1个结果");
    JTextField textStudentID = new JTextField(10);
    JTextField textHouseID = new JTextField(10);
    JTextField textRoomID = new JTextField(10);
    JTextField textBedID = new JTextField(10);
    JButton confirm = new JButton("确认调换");
    JButton add = new JButton("确认分配");
    DefaultTableModel defaultTableModel;
    JTable jTable;
    JScrollPane jsp;
    String[] titleStudent = {"学生ID","楼号","房号","床号","入住日期","离开日期","备注"};
    String[][] data = {};
    int sid;
    int bid;
    int rid;
    int bed;
    public static boolean isSwitch = false;
    public static boolean isAdd = false;
    public static boolean isClosing = false;
    public static boolean isListened = false;
//    public String lableStudentID;
//    public String lableHouseID;
//    public String lableRoomID;
//    public String lableBedID;
    // JLabel ji=new JLabel()
    public SwitchStudentGUI(){
        //部件添加
        jFrame.setBounds(550,250,770, 500);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jPanel.setLayout(null);
        jFrame.add(jPanel);

        //设置标签和文本框位置
        lableStudentID.setBounds(10,10,50,25);
        lableHouseID.setBounds(140,10,100,25);
        lableRoomID.setBounds(300,10,50,25);
        lableBedID.setBounds(470,10,50,25);
        textStudentID.setBounds(60,10,70,25);
        textHouseID.setBounds(220,10,70,25);
        textRoomID.setBounds(370,10,70,25);
        textBedID.setBounds(500,10,70,25);
        result.setBounds(10,30,640,25);

        //设置按钮位置
        confirm.setBounds(660,10,90,25);
        add.setBounds(660,40,90,25);

        //添加部件
        jPanel.add(lableStudentID);jPanel.add(lableHouseID);jPanel.add(lableRoomID);jPanel.add(lableBedID);
        jPanel.add(textStudentID);jPanel.add(textHouseID);jPanel.add(textRoomID);jPanel.add(textBedID);
        jPanel.add(confirm);jPanel.add(result);jPanel.add(add);

        defaultTableModel = new DefaultTableModel(data,titleStudent);
        jTable = new JTable(defaultTableModel);
        jTable.setPreferredScrollableViewportSize(new Dimension(550, 100));
        jTable.setRowHeight(20);

        jsp = new JScrollPane(jTable);
        jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        jsp.setBounds(10,50,650,400);
        jsp.setWheelScrollingEnabled(false);
//        System.out.println(jsp.isWheelScrollingEnabled());
        jPanel.add(jsp);

        confirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//                System.out.println("changed");
                bid = Integer.parseInt(textHouseID.getText());
                rid = Integer.parseInt(textRoomID.getText());
                bed = Integer.parseInt(textBedID.getText());
                sid = Integer.parseInt(textStudentID.getText());
                isSwitch = true;
                isListened = true;
            }
        });

        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//                System.out.println("changed");
                bid = Integer.parseInt(textHouseID.getText());
                rid = Integer.parseInt(textRoomID.getText());
                bed = Integer.parseInt(textBedID.getText());
                sid = Integer.parseInt(textStudentID.getText());
                isAdd = true;
                isListened = true;
            }
        });

        jFrame.addWindowListener(new WindowListener(){
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
//                jFrame.dispose();
                isClosing = true;
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });
    }

    public int getSid() {
        return sid;
    }

    public int getBid() {
        return bid;
    }

    public int getRid() {
        return rid;
    }

    public int getBed() {
        return bed;
    }

    public void init(){
        isSwitch = false;
        isAdd  = false;
        isListened = false;
        isClosing = false;
    }

    public boolean isListened(){
        return isListened;
    }

    public boolean isClosing(){
        return isClosing;
    }

    public void clearTable(){
        defaultTableModel.getDataVector().clear();
        jTable.clearSelection();
        jPanel.remove(jsp);
//        jsp.setColumnHeader(null);
    }

    public void switchStudent(){
        Viewer v = new Viewer();
        defaultTableModel = new DefaultTableModel(data,titleStudent);
        jTable = new JTable(defaultTableModel);
        jTable.setPreferredScrollableViewportSize(new Dimension(550, 100));
        jTable.setRowHeight(20);

        jsp = new JScrollPane(jTable);
        jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        jsp.setBounds(10,50,650,400);
        jPanel.add(jsp);

        try{
            ResultSet rs;
            if(isSwitch){
                rs = v.findRoom_byStudentID2(this.getSid());
                do{
                    Vector<String> vector = new Vector<String>();
                    vector.addElement(rs.getString(1));
                    vector.addElement(rs.getString(2));
                    vector.addElement(rs.getString(3));
                    vector.addElement(rs.getString(4));
                    vector.addElement(rs.getString(5));
                    vector.addElement(rs.getString(6));
                    vector.addElement(rs.getString(7));
                    defaultTableModel.addRow(vector);
                }while(rs.next());
            }

            v.addAccommodation(sid,bid,rid,bed);

            rs = v.findRoom_byStudentID2(this.getSid());
            do{
                Vector<String> vector = new Vector<String>();
                vector.addElement(rs.getString(1));
                vector.addElement(rs.getString(2));
                vector.addElement(rs.getString(3));
                vector.addElement(rs.getString(4));
                vector.addElement(rs.getString(5));
                vector.addElement(rs.getString(6));
                vector.addElement(rs.getString(7));
                defaultTableModel.addRow(vector);
            }while(rs.next());
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void main(String[] args){
        new SwitchStudentGUI();
    }
}
