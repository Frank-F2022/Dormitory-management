package GUI;

import javax.swing.*;

public class AddStudentFailedGUI {
    JFrame jFrame = new JFrame("学生信息添加失败");
    public AddStudentFailedGUI() {
        //实例化一个JDialog类对象，指定对话框的父窗体、窗体标题和类型
        //super(frame, "JDialog窗体", true);
        jFrame.setBounds(500,200,350, 150);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        // container = getContentPane();                    //创建一个容器
        jFrame.add(new JLabel("<html>已存在对应学号的学生<br>" +
                "已在表格中生成该学号学生的信息<br>请关闭该窗口以重新输入</html>",JLabel.CENTER));  //在容器中添加标签
        //moji.setBounds(120, 120, 150, 100);          //设置对话框窗体大小
    }
}

class InvalidStudentIDGUI{
    JFrame jFrame = new JFrame("学生学号非法");
    public InvalidStudentIDGUI() {
        //实例化一个JDialog类对象，指定对话框的父窗体、窗体标题和类型
        //super(frame, "JDialog窗体", true);
        jFrame.setBounds(500,200,350, 150);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        // container = getContentPane();                    //创建一个容器
        jFrame.add(new JLabel("<html>学生学号非法<br>" +
                "请输入7位学号<br>7位学号前4位需要和入学年份一致</html>",JLabel.CENTER));  //在容器中添加标签
        //moji.setBounds(120, 120, 150, 100);          //设置对话框窗体大小
    }
}

class InvalidGenderGUI{
    JFrame jFrame = new JFrame("学生性别非法");
    public InvalidGenderGUI() {
        //实例化一个JDialog类对象，指定对话框的父窗体、窗体标题和类型
        //super(frame, "JDialog窗体", true);
        jFrame.setBounds(500,200,350, 150);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        // container = getContentPane();                    //创建一个容器
        jFrame.add(new JLabel("<html>学生性别非法<br>" +
                "请输入大写M或F</html>",JLabel.CENTER));  //在容器中添加标签
        //moji.setBounds(120, 120, 150, 100);          //设置对话框窗体大小
    }
}

class InvalidGradeGUI{
    JFrame jFrame = new JFrame("学生年级非法");
    public InvalidGradeGUI() {
        //实例化一个JDialog类对象，指定对话框的父窗体、窗体标题和类型
        //super(frame, "JDialog窗体", true);
        jFrame.setBounds(500,200,350, 150);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        // container = getContentPane();                    //创建一个容器
        jFrame.add(new JLabel("<html>学生年级非法<br>" +
                "请输入2000年及其之后年份的4位数字</html>",JLabel.CENTER));  //在容器中添加标签
        //moji.setBounds(120, 120, 150, 100);          //设置对话框窗体大小
    }
}

class InvalidPhoneNumberGUI{
    JFrame jFrame = new JFrame("学生电话号码非法");
    public InvalidPhoneNumberGUI() {
        //实例化一个JDialog类对象，指定对话框的父窗体、窗体标题和类型
        //super(frame, "JDialog窗体", true);
        jFrame.setBounds(500,200,350, 150);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        // container = getContentPane();                    //创建一个容器
        jFrame.add(new JLabel("<html>学生电话号码非法<br>" +
                "请输入11位且号段正确的电话号码</html>",JLabel.CENTER));  //在容器中添加标签
        //moji.setBounds(120, 120, 150, 100);          //设置对话框窗体大小
    }
}

