package GUI;

import javax.swing.*;

public class AddBuildingFailedGUI {
    JFrame jFrame = new JFrame("宿舍楼信息添加失败");
    public AddBuildingFailedGUI() {
        //实例化一个JDialog类对象，指定对话框的父窗体、窗体标题和类型
        //super(frame, "JDialog窗体", true);
        jFrame.setBounds(500,200,350, 150);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        // container = getContentPane();                    //创建一个容器
        jFrame.add(new JLabel("<html>已存在对应楼号的宿舍楼<br>" +
                "已在表格中生成该宿舍楼的信息<br>请关闭该窗口以重新输入</html>",JLabel.CENTER));  //在容器中添加标签
        //moji.setBounds(120, 120, 150, 100);          //设置对话框窗体大小
    }
}

class InvalidStudentNumberInRoomsGUI {
    JFrame jFrame = new JFrame("学生数量与房间数量不匹配");
    public InvalidStudentNumberInRoomsGUI() {
        //实例化一个JDialog类对象，指定对话框的父窗体、窗体标题和类型
        //super(frame, "JDialog窗体", true);
        jFrame.setBounds(500,200,350, 150);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        // container = getContentPane();                    //创建一个容器
        jFrame.add(new JLabel("<html>最大可容纳学生数量与房间数量不匹配<br>" +
                "学生数量应为房间数量的4倍<br>请重新输入</html>",JLabel.CENTER));  //在容器中添加标签
        //moji.setBounds(120, 120, 150, 100);          //设置对话框窗体大小
    }
}
