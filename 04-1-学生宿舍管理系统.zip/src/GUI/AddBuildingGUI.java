package GUI;

import user.Root;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.sql.ResultSet;
import java.util.Vector;

//新增学生 信息输入界面
public class AddBuildingGUI {
    JFrame a=new JFrame("新增宿舍楼");
    JPanel p10=new JPanel();
    JLabel j1=new JLabel("宿舍楼ID");
    JLabel j2=new JLabel("宿舍楼名称");
    JLabel j3=new JLabel("宿舍楼地址");
    JLabel j4=new JLabel("楼层数");
    JLabel j5=new JLabel("房间数");
    JLabel j6=new JLabel("最大学生数");
//    JLabel j7=new JLabel("房间数");
    JTextField buildingid=new JTextField(15);
    JTextField buildingName=new JTextField(15);
    JTextField buildingFloors=new JTextField(15);
//    JTextField studentdept=new JTextField(15);
    JTextField buildingAddress=new JTextField(15);
    JTextField buildingMaxStudent=new JTextField(15);
    JTextField buildingRooms=new JTextField(15);
    JButton yes =new JButton("确认");
    public static boolean isClosing = false;
    public static boolean isListened = false;
    String[] titleBuilding = {"宿舍楼ID","宿舍楼名称","地址","楼层数","最大学生数","房间数"};
    String[][] data = {};
    DefaultTableModel defaultTableModel;
    JTable jTable;
    JScrollPane jsp;
    int bid;
    String bname;
    String baddress;
    int bfloor;
//    String sdept;
    int bstudent;
    int broom;
    public AddBuildingGUI(){
        a.setBounds(550,250,700, 400);
        a.setVisible(true);
        a.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        p10.setLayout(null);
        a.add(p10);

        j1.setBounds(10,10,50,25);
        j2.setBounds(160,10,80,25);
        j3.setBounds(360,10,100,25);
        j4.setBounds(10,40,50,25);
        j5.setBounds(360,40,80,25);
        j6.setBounds(160,40,100,25);
//        j7.setBounds(530,10,50,25);

        buildingid.setBounds(70,10,80,25);
        buildingName.setBounds(230,10,120,25);
        buildingAddress.setBounds(440,10,120,25);
//        studentdept.setBounds(590,10,80,25);
        buildingFloors.setBounds(70,40,80,25);
        buildingRooms.setBounds(440,40,120,25);
        buildingMaxStudent.setBounds(230,40,120,25);

        yes.setBounds(590,40,80,25);

        p10.add(j1);p10.add(j2);p10.add(j3);
        p10.add(j4);
        p10.add(j5);p10.add(j6);
//        p10.add(j7);
        p10.add(buildingid);p10.add(buildingName);
        p10.add(buildingAddress);
        p10.add(buildingFloors);
//        p10.add(studentdept);
        p10.add(buildingMaxStudent);
        p10.add(buildingRooms);
        p10.add(yes);

        yes.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                bid = Integer.parseInt(buildingid.getText());
                bname = buildingName.getText();
                baddress = buildingAddress.getText();
//                sdept = studentdept.getText();
                bfloor = Integer.parseInt(buildingFloors.getText());
                bstudent = Integer.parseInt(buildingMaxStudent.getText());
                broom = Integer.parseInt(buildingRooms.getText());
                if(bstudent != 4 * broom){
                    new InvalidStudentNumberInRoomsGUI();
                    isListened = false;
                    return;
                }
                isListened = true;
            }
        });
        a.addWindowListener(new WindowListener(){
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
//                jFrame.dispose();
                isClosing = true;
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });
    }

    public int getBid() {
        return bid;
    }

    public void init(){
        isListened = false;
        isClosing = false;
    }

    public boolean isListened(){
        return isListened;
    }

    public boolean isClosing(){
        return isClosing;
    }

    public void clearTable(){
        defaultTableModel.getDataVector().clear();
        jTable.clearSelection();
        a.remove(jsp);
//        jsp.setColumnHeader(null);
    }

    public void showBuildingTable(ResultSet rs){
        defaultTableModel = new DefaultTableModel(data,titleBuilding);
        jTable = new JTable(defaultTableModel);
        jTable.setPreferredScrollableViewportSize(new Dimension(550, 300));
        jTable.setRowHeight(20);
        jTable.setBounds(10,80,550,300);

        jsp = new JScrollPane(jTable);
        jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        jsp.setBounds(10,80,650,300);
        jsp.setWheelScrollingEnabled(false);
//        System.out.println(jsp.isWheelScrollingEnabled());
        a.add(jsp);

        try{
            while(rs.next()){
                Vector<String> vector = new Vector<String>();
                vector.addElement(rs.getString(1));
                vector.addElement(rs.getString(2));
                vector.addElement(rs.getString(3));
                vector.addElement(rs.getString(4));
                vector.addElement(rs.getString(5));
                vector.addElement(rs.getString(6));
                defaultTableModel.addRow(vector);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void showResult() {
        Root r = new Root();
        r.addBuilding(bid,bname,baddress,bfloor,bstudent,broom);
        showBuildingTable(r.findBuilding_byBuildingID(bid));
    }

    public static void main(String[] args){
       new AddBuildingGUI();
    }
}
