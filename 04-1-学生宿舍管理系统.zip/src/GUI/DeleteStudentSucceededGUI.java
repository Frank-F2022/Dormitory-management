package GUI;

import javax.swing.*;
public class DeleteStudentSucceededGUI{
    JFrame jFrame = new JFrame("删除成功");
    public DeleteStudentSucceededGUI() {
        //实例化一个JDialog类对象，指定对话框的父窗体、窗体标题和类型
        //super(frame, "JDialog窗体", true);
        jFrame.setBounds(500,200,350, 150);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        // container = getContentPane();                    //创建一个容器
        jFrame.add(new JLabel("删除成功！",JLabel.CENTER));           //在容器中添加标签
        //moji.setBounds(120, 120, 150, 100);          //设置对话框窗体大小
    }
}
