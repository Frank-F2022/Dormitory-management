package GUI;

import user.Viewer;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.util.Vector;

public class SearchGUI {
    //初始化变量
    JFrame jFrame = new JFrame("查找");
    JPanel pSearch = new JPanel();
    JButton buildSearchStu = new JButton("楼号+房号+床号查学生");
    JButton buildRoomSearchStu = new JButton("楼号+房号查房间全部学生");
    //  JButton b2=new JButton("根据学生查找宿舍");
    //  JButton stuidSearchStu=new JButton("调换宿舍");
    // JButton buildidSearchRoom=new JButton("学生信息管理");
    // JButton showAllBuild=new JButton("宿舍楼管理");
    //  JButton b6=new JButton("房间管理");
    JButton stuidSearchStu = new JButton("学生ID查学生住宿信息");
    JButton buildidSearchRoom = new JButton("楼ID查宿舍");
    JButton showAllStudent = new JButton("显示全部学生信息");
    JButton showAllBuild = new JButton("显示全部宿舍楼信息");
    JButton returnMain = new JButton("返回主界面");
    JLabel lStu = new JLabel("学生ID");
    JLabel lBuild = new JLabel("宿舍楼ID");
    JLabel lRoom = new JLabel("房间ID");
    JLabel lBed = new JLabel("床ID");
    JTextField stuID = new JTextField(10);
    JTextField buildID = new JTextField(10);
    JTextField roomID = new JTextField(10);
    JTextField bedID = new JTextField(10);
//    JTextArea show = new JTextArea(30,30);
    String[] titleStudent = {"学生ID","姓名","性别","学院","专业","手机号码","年级"};
    String[] titleStudentAccommodation = {"学生ID","姓名","楼号","房间号","床号","入住日期","离开日期"};
    String[] titleRoom = {"楼号","房间号","备注"};
    String[] titleBuilding = {"楼号","名称","地址","层数","最大容纳学生数","房间数"};
    String[][] data = {};
    DefaultTableModel defaultTableModel;
    JTable jTable;
    JScrollPane jsp;
//    JScrollPane jsp = new JScrollPane(show);
    // JButton daochu=new JButton("一键导出");
    int sid;
    int bid;
    int rid;
    int bed;
    public static boolean isBuildSearchStu = false;
    public static boolean isShowRoomStudent = false;
    public static boolean isStuidSearchStu = false;
    public static boolean isBuildSearchRoom = false;
    public static boolean isShowAllStudent = false;
    public static boolean isShowAllBuilding = false;
    public static boolean isReturnMain = false;
    public static boolean isListened = false;
    public static boolean isClosing = false;
    public SearchGUI(){
        //部件添加到GUI上
        jFrame.setBounds(550,250,860, 500);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        pSearch.setLayout(null);
//        jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        jFrame.add(pSearch);

        //设置按钮部件位置和大小
        //  daochu.setBounds(660,300,130,25);
        buildSearchStu.setBounds(660,50,180,25);
        buildRoomSearchStu.setBounds(660,90,180,25);
        stuidSearchStu.setBounds(660,130,180,25);
        buildidSearchRoom.setBounds(660,170,180,25);
        showAllStudent.setBounds(660,210,180,25);
        showAllBuild.setBounds(660,250,180,25);
        returnMain.setBounds(660,420,180,25);

        //设置文本框和标签部件位置和大小
        lStu.setBounds(10,10,50,25);
        stuID.setBounds(60,10,70,25);
        lBuild.setBounds(140,10,50,25);
        buildID.setBounds(190,10,70,25);
        lRoom.setBounds(270,10,50,25);
        roomID.setBounds(320,10,70,25);
        lBed.setBounds(400,10,50,25);
        bedID.setBounds(430,10,70,25);
        //show.setBounds(10,50,650,400);
        // JScrollPane jsp=new JScrollPane(textArea);
//        jsp.setBounds(10,50,650,400);
        // show.setEditable(false);
//        pSearch.add(jsp);

        //添加文本框和标签部件
        pSearch.add(lStu);pSearch.add(lBuild);pSearch.add(buildID);pSearch.add(lRoom);pSearch.add(lBed);
        pSearch.add(stuID);pSearch.add(roomID);pSearch.add(bedID);
        //p7.add(show);
        //p7.add(daochu);

        //添加按钮部件
        pSearch.add(buildSearchStu);pSearch.add(stuidSearchStu);
        pSearch.add(buildidSearchRoom);pSearch.add(buildRoomSearchStu);
        pSearch.add(showAllStudent);pSearch.add(showAllBuild);
        pSearch.add(returnMain);

        //按钮监听器设置
        buildSearchStu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                bid = Integer.parseInt(buildID.getText());
                rid = Integer.parseInt(roomID.getText());
                bed = Integer.parseInt(bedID.getText());
                isBuildSearchStu = true;
                isListened = true;
            }
        });
        buildRoomSearchStu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                bid = Integer.parseInt(buildID.getText());
                rid = Integer.parseInt(roomID.getText());
                isShowRoomStudent = true;
                isListened = true;
            }
        });
        stuidSearchStu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sid=Integer.parseInt(stuID.getText());
                isStuidSearchStu = true;
                isListened = true;
            }
        });
        buildidSearchRoom.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                bid=Integer.parseInt(buildID.getText());
                isBuildSearchRoom = true;
                isListened = true;
            }
        });
        showAllStudent.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                isShowAllStudent = true;
                isListened = true;
            }
        });
        showAllBuild.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                isShowAllBuilding = true;
                isListened = true;
            }
        });
        returnMain.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jFrame.dispose();
                isClosing = true;
            }
        });
        jFrame.addWindowListener(new WindowListener(){
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
//                jFrame.dispose();
                isClosing = true;
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });
    }

    public int getSid() {
        return sid;
    }

    public int getBid() {
        return bid;
    }

    public int getRid() {
        return rid;
    }

    public int getBed() {
        return bed;
    }

    public boolean isListened(){
        return isListened;
    }

    public boolean isClosing(){
        return isClosing;
    }

    public void init(){
        isBuildSearchStu = false;
        isStuidSearchStu = false;
        isShowRoomStudent = false;
        isBuildSearchRoom = false;
        isShowAllStudent = false;
        isShowAllBuilding = false;
        isReturnMain = false;
        isListened = false;
        isClosing = false;
    }

    public void showStudentTable(ResultSet rs){
        defaultTableModel = new DefaultTableModel(data,titleStudent);
        jTable = new JTable(defaultTableModel);
        jTable.setPreferredScrollableViewportSize(new Dimension(550, 100));
        jTable.setRowHeight(20);

        jsp = new JScrollPane(jTable);
        jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        jsp.setBounds(10,50,650,400);
        jsp.setWheelScrollingEnabled(false);
//        System.out.println(jsp.isWheelScrollingEnabled());
        pSearch.add(jsp);

        try{
            do{
                Vector<String> vector = new Vector<String>();
                vector.addElement(rs.getString(1));
                vector.addElement(rs.getString(2));
                vector.addElement(rs.getString(3));
                vector.addElement(rs.getString(4));
                vector.addElement(rs.getString(5));
                vector.addElement(rs.getString(6));
                vector.addElement(rs.getString(7));
                defaultTableModel.addRow(vector);
            }while(rs.next());
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void showStudentTable(ResultSet[] rs){
        defaultTableModel = new DefaultTableModel(data,titleStudent);
        jTable = new JTable(defaultTableModel);
        jTable.setPreferredScrollableViewportSize(new Dimension(550, 100));
        jTable.setRowHeight(20);

        jsp = new JScrollPane(jTable);
        jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        jsp.setBounds(10,50,650,400);
        jsp.setWheelScrollingEnabled(false);
//        System.out.println(jsp.isWheelScrollingEnabled());
        pSearch.add(jsp);
        for(int i=0;i<rs.length;i++){
            try{
                do{
                    Vector<String> vector = new Vector<String>();
                    vector.addElement(rs[i].getString(1));
                    vector.addElement(rs[i].getString(2));
                    vector.addElement(rs[i].getString(3));
                    vector.addElement(rs[i].getString(4));
                    vector.addElement(rs[i].getString(5));
                    vector.addElement(rs[i].getString(6));
                    vector.addElement(rs[i].getString(7));
                    defaultTableModel.addRow(vector);
                }while(rs[i].next());
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    public void showStudentAccommodationTable(ResultSet rs){
        defaultTableModel = new DefaultTableModel(data,titleStudentAccommodation);
        jTable = new JTable(defaultTableModel);
        jTable.setPreferredScrollableViewportSize(new Dimension(550, 100));
        jTable.setRowHeight(20);

        jsp = new JScrollPane(jTable);
        jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        jsp.setBounds(10,50,650,400);
        jsp.setWheelScrollingEnabled(false);
//        System.out.println(jsp.isWheelScrollingEnabled());
        pSearch.add(jsp);

        try{
            do{
                Vector<String> vector = new Vector<String>();
                vector.addElement(rs.getString(1));
                vector.addElement(rs.getString(2));
                vector.addElement(rs.getString(9));
                vector.addElement(rs.getString(10));
                vector.addElement(rs.getString(11));
                vector.addElement(rs.getString(12));
                vector.addElement(rs.getString(13));
                defaultTableModel.addRow(vector);
            }while(rs.next());
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void showRoomTable(ResultSet rs){
        defaultTableModel = new DefaultTableModel(data,titleRoom);
        jTable = new JTable(defaultTableModel);
        jTable.setPreferredScrollableViewportSize(new Dimension(550, 100));
        jTable.setRowHeight(20);

        jsp = new JScrollPane(jTable);
        jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        jsp.setBounds(10,50,650,400);
//        System.out.println(jsp.isWheelScrollingEnabled());
        pSearch.add(jsp);

        try{
            while(rs.next()){
                Vector<String> vector = new Vector<String>();
                vector.addElement(rs.getString(1));
                vector.addElement(rs.getString(2));
                vector.addElement(rs.getString(3));
                defaultTableModel.addRow(vector);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void showStudentTableWithScroll(ResultSet rs){
        defaultTableModel = new DefaultTableModel(data,titleStudent);
        jTable = new JTable(defaultTableModel);
        jTable.setPreferredScrollableViewportSize(new Dimension(550, 100));
        jTable.setRowHeight(20);

        jsp = new JScrollPane(jTable);
        jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        jsp.setBounds(10,50,650,400);
        pSearch.add(jsp);

        try{
            while(rs.next()){
                Vector<String> vector = new Vector<String>();
                vector.addElement(rs.getString(1));
                vector.addElement(rs.getString(2));
                vector.addElement(rs.getString(3));
                vector.addElement(rs.getString(4));
                vector.addElement(rs.getString(5));
                vector.addElement(rs.getString(6));
                vector.addElement(rs.getString(7));
                defaultTableModel.addRow(vector);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void showBuildingTableWithScroll(ResultSet rs){
        defaultTableModel = new DefaultTableModel(data,titleBuilding);
        jTable = new JTable(defaultTableModel);
        jTable.setPreferredScrollableViewportSize(new Dimension(550, 100));
        jTable.setRowHeight(20);

        jsp = new JScrollPane(jTable);
        jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        jsp.setBounds(10,50,650,400);
        pSearch.add(jsp);

        try{
            while(rs.next()){
                Vector<String> vector = new Vector<String>();
                vector.addElement(rs.getString(1));
                vector.addElement(rs.getString(2));
                vector.addElement(rs.getString(3));
                vector.addElement(rs.getString(4));
                vector.addElement(rs.getString(5));
                vector.addElement(rs.getString(6));
                defaultTableModel.addRow(vector);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void clearTable(){
        defaultTableModel.getDataVector().clear();
        jTable.clearSelection();
        pSearch.remove(jsp);
//        jsp.setColumnHeader(null);
    }

    public void showResult(){
        Viewer v = new Viewer();
        if(isBuildSearchStu){
            showStudentTable(v.findStudent_byRoom1(this.getBid(), this.getRid(), this.getBed()));
        }else if(isStuidSearchStu){
            showStudentAccommodationTable(v.findRoom_byStudentID3(this.getSid()));
        }else if(isShowAllStudent){
            showStudentTableWithScroll(v.findStudent_all1());
        }else if(isShowRoomStudent){
            showStudentTable(v.findRoom_Student1(this.getBid(),this.getRid()));
        }else if(isBuildSearchRoom){
            showRoomTable(v.findRoom_byHouseID1(this.getBid()));
        }else if(isShowAllBuilding){
            showBuildingTableWithScroll(v.findBuilding_all1());
        }
    }

    public static void main(String[] args){
        new SearchGUI();
    }
}
