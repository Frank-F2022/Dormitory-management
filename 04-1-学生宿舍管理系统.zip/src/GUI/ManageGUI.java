package GUI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

//6个按钮
public class ManageGUI {
    JFrame jFrame = new JFrame("管理");
    JPanel p9 = new JPanel();
    JLabel studentl = new JLabel("学生信息管理");
    JLabel housel = new JLabel("宿舍楼管理");
    JLabel rooml = new JLabel("宿舍房间管理");
    JButton addstu = new JButton("新增学生");
    JButton delstu = new JButton("删除学生");
    JButton importstu = new JButton("文件导入");
    JButton addhouse = new JButton("新增宿舍楼");
    JButton delhouse = new JButton("删除宿舍楼");
    JButton addroom = new JButton("新增房间");
    JButton delroom = new JButton("删除房间");
    public static boolean isAddStudent = false;
    public static boolean isDeleteStudent = false;
    public static boolean isImportStudent = false;
    public static boolean isAddRoom = false;
    public static boolean isDeleteRoom = false;
    public static boolean isAddBuilding = false;
    public static boolean isDeleteBuilding = false;
    public static boolean isClosing = false;
    public static boolean isListened = false;
    public ManageGUI(){

        jFrame.setBounds(550,250,500, 350);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        p9.setLayout(null);
        jFrame.add(p9);

        studentl.setBounds(215,20,100,25);
        addstu.setBounds(90,60,100,25);
        delstu.setBounds(205,60,100,25);
        importstu.setBounds(320,60,100,25);
        rooml.setBounds(215,100,100,25);
        addroom.setBounds(140,140,100,25);
        delroom.setBounds(260,140,100,25);
        housel.setBounds(220,180,100,25);
        addhouse.setBounds(140,220,100,25);
        delhouse.setBounds(260,220,100,25);
        p9.add(studentl);p9.add(housel);p9.add(rooml);
        p9.add(addstu);p9.add(delstu);p9.add(importstu);
        p9.add(addhouse);p9.add(delhouse);
        p9.add(addroom);p9.add(delroom);

        addstu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//                new I10();
                isAddStudent = true;
                isListened = true;
            }
        });
        delstu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//                new I11();
                isDeleteStudent = true;
                isListened = true;
            }
        });
        importstu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//                new I11();
                isImportStudent = true;
                isListened = true;
            }
        });
        addroom.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//                new I12();
                isAddRoom = true;
                isListened = true;
            }
        });
        delroom.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//                new I13();
                isDeleteRoom = true;
                isListened = true;
            }
        });
        addhouse.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//                new I14();
                isAddBuilding = true;
                isListened = true;
            }
        });
        delhouse.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//                new I15();
                isDeleteBuilding = true;
                isListened = true;
            }
        });

        jFrame.addWindowListener(new WindowListener(){
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
//                jFrame.dispose();
                isClosing = true;
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });
    }

    public boolean isListened(){
        return isListened;
    }

    public boolean isClosing(){
        return isClosing;
    }

    public void init(){
        isAddStudent = false;
        isDeleteStudent = false;
        isImportStudent = false;
        isAddRoom = false;
        isDeleteRoom = false;
        isAddBuilding = false;
        isDeleteBuilding = false;
        isListened = false;
        isClosing = false;
    }

    public void close(){
        jFrame.dispose();
    }

    public static void main(String[] args){
        new ManageGUI();
    }
}
