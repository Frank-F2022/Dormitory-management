package GUI;

import javax.swing.*;
import java.awt.event.*;

//选择功能界面，选择查找，管理，登出，退出。
public class ViewerGUI {
    //初始化变量
    JFrame jFrame = new JFrame("普通用户功能选择");
    JPanel pp = new JPanel();
    JButton search = new JButton("查找");
    JButton bSwitch = new JButton("学生分配或调换宿舍");
    JButton logout=new JButton("登出");
    JButton exit=new JButton("退出");
    public static boolean isSearch = false;
    public static boolean isSwitch = false;
//    public static boolean isManage = false;
    public static boolean isLogout = false;
    public static boolean isExit = false;
    public static boolean isListened = false;

    public ViewerGUI() {
        //实例化一个JDialog类对象，指定对话框的父窗体、窗体标题和类型
        //super(frame, "JDialog窗体", true);
        jFrame.setBounds(500,200,550, 320);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // ll.setIcon(icon);
        //  ll.setBounds(0, 0, icon.getIconWidth(), icon.getIconHeight()); // 设置组件的显示位置及大小
        //aa.getContentPane().add(ll);
        pp.setLayout(null);
        jFrame.add(pp);
        //  ll.setBounds(10 ,10,10 ,10);
        // container = getContentPane();
        // pp.add(ll);           //在容器中添加标签
//        bSwitch.setBounds( 10,20,150,25);
//        bManage.setBounds(200,20,150,25);
//        b3.setBounds(380,20,150,25);
//        b4.setBounds(10,60,150,25);
//        b5.setBounds(200,60,150,25);
//        b6.setBounds(380,60,150,25);
//        b7.setBounds(10,100,150,25);
//        b8.setBounds(200,100,150,25);
//        b9.setBounds(380,100,150,25);
        search.setBounds(200,20,150,25);
        // guan.setBounds(200,60,150,25);
        bSwitch.setBounds(200 ,60,150,25);
//        bManage.setBounds(200,100,150,25);
        //   b3.setBounds(110,100,150,25);
        // b4.setBounds(310,100,150,25);
        logout.setBounds(450,200,60,25);
        exit.setBounds(450,240,60,25);
//        pp.add(bSwitch);
//        pp.add(bManage);
//        pp.add(b3);pp.add(b4);pp.add(b5);pp.add(b6);
//        pp.add(b7);pp.add(b8);pp.add(b9);
        pp.add(search);
        pp.add(bSwitch);
//        pp.add(bManage);

        // pp.add(guan);
        pp.add(logout);
        pp.add(exit);

        search.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//                new SearchGUI();
//                SearchGUI searchGUI = new SearchGUI();

                isSearch = true;
                isListened = true;
            }
        });
        bSwitch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //I8 i8=new I8();

                isSwitch = true;
                isListened = true;
            }
        });
//        bManage.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                //I9 i9=new I9();
//            }
//        });
        logout.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jFrame.dispose();
                isLogout = true;
                isListened = true;
            }
        });
        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jFrame.dispose();
                isExit = true;
                isListened = true;
            }
        });
    }

    public boolean isListened(){
        return isListened;
    }

    public void init(){
        isSearch = false;
        isSwitch = false;
//        isManage = false;
        isLogout = false;
        isExit = false;
        isListened = false;
    }

    public void close(){
        jFrame.dispose();
    }
}

