package GUI;

import user.Root;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class DeleteRoomGUI {
    JFrame a=new JFrame("删除房间");
    JPanel p11=new JPanel();

    JLabel j1=new JLabel("要删除的房间ID");
    JLabel j2=new JLabel("要删除的房间所在宿舍楼ID");
    JTextField roomID=new JTextField(15);
    JTextField buildingID=new JTextField(15);
    JButton yes =new JButton("确认");

    public static boolean isClosing = false;
    public static boolean isListened = false;

    int roomid;//学生id获取
    int buildingid;
    public DeleteRoomGUI(){
        a.setBounds(550,250,350, 200);
        a.setVisible(true);
        a.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        p11.setLayout(null);
        a.add(p11);
        j1.setBounds(30,20,180,25);
        roomID.setBounds(200,20,100,25);
        j2.setBounds(30,60,180,25);
        buildingID.setBounds(200,60,100,25);
        yes.setBounds(220,100,80,25);
        p11.add(roomID);p11.add(j1);
        p11.add(buildingID);p11.add(j2);
        p11.add(yes);

        yes.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                roomid = Integer.parseInt(roomID.getText());
                buildingid = Integer.parseInt(buildingID.getText());
                isListened = true;
            }
        });
        a.addWindowListener(new WindowListener(){
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
//                jFrame.dispose();
                isClosing = true;
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });
    }

    public void init(){
        isListened = false;
        isClosing = false;
    }

    public boolean isListened(){
        return isListened;
    }

    public boolean isClosing(){
        return isClosing;
    }

    public void delete() {
        Root r = new Root();
        r.deleteRoom(buildingid,roomid);
    }

    public static void main(String[] args){
        new DeleteRoomGUI();
    }
}
