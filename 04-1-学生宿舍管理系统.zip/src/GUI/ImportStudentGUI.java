package GUI;

import database.StudentExcelUtils;
import user.Viewer;

import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.sql.ResultSet;
import java.util.Vector;

//新增学生 信息输入界面
public class ImportStudentGUI {
    JFrame a = new JFrame("学生信息批量导入");
    JPanel p10 = new JPanel();
    JButton selectFile =new JButton("选择");
    JButton importFile =new JButton("导入");
    JFileChooser fc = new JFileChooser();
    JTextPane t = new JTextPane();
    public static boolean isSelect = false;
    public static boolean isImport = false;
    public static boolean isClosing = false;
    public static boolean isListened = false;
    String[] titleStudent = {"学生ID","姓名","性别","学院","专业","手机号码","年级"};
    String[][] data = {};
    DefaultTableModel defaultTableModel;
    JTable jTable;
    JScrollPane jsp;
    String pathSelected;
    String pathToImport;
    public ImportStudentGUI(){
        a.setBounds(550,250,800, 400);
        a.setVisible(true);
        a.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        p10.setLayout(null);
        a.add(p10);

        selectFile.setBounds(610,10,80,25);
        importFile.setBounds(700,10,80,25);
        t.setBounds(10,12,580,20);

        p10.add(selectFile);
        p10.add(importFile);
        p10.add(t);

        defaultTableModel = new DefaultTableModel(data,titleStudent);
        jTable = new JTable(defaultTableModel);
        jTable.setPreferredScrollableViewportSize(new Dimension(550, 300));
        jTable.setRowHeight(20);
        jTable.setBounds(10,45,770,300);

        jsp = new JScrollPane(jTable);
        jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        jsp.setBounds(10,45,770,300);
        p10.add(jsp);

        fc.setFileFilter(new FileFilter() {
            @Override
            public String getDescription() {
                return "Excel文件(*.xls)";
            }

            @Override
            public boolean accept(File f) {
                if(f.getName().toLowerCase().endsWith(".xls")) {
                    return true;
                }
                return false;
            }
        });
        selectFile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                isSelect = true;
                fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
                fc.showOpenDialog(null);
                File f = fc.getSelectedFile();//使用文件类获取选择器选择的文件
                if(f!=null) {
                    pathSelected = f.getAbsolutePath();//返回路径名
                    t.setText(pathSelected);
//                    System.out.println(pathSelected);
                }
            }
        });
        importFile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!isSelect){
                    return;
                }
                pathToImport = t.getText();
                isImport = true;
                isListened = true;
                System.out.println(pathToImport);
            }
        });
        a.addWindowListener(new WindowListener(){
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
//                jFrame.dispose();
                isClosing = true;
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });
    }

    public void init(){
        isSelect = false;
        isImport = false;
        isListened = false;
        isClosing = false;
    }

    public boolean isListened(){
        return isListened;
    }

    public boolean isClosing(){
        return isClosing;
    }

    public void clearTable(){
        defaultTableModel.getDataVector().clear();
        jTable.clearSelection();
        a.remove(jsp);
//        jsp.setColumnHeader(null);
    }

    public void showStudentTable(ResultSet rs){
        try{
            while(rs.next()){
                Vector<String> vector = new Vector<String>();
                vector.addElement(rs.getString(1));
                vector.addElement(rs.getString(2));
                vector.addElement(rs.getString(3));
                vector.addElement(rs.getString(4));
                vector.addElement(rs.getString(5));
                vector.addElement(rs.getString(6));
                vector.addElement(rs.getString(7));
                defaultTableModel.addRow(vector);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void showResult() {
        Viewer v = new Viewer();
        StudentExcelUtils.addStudentsByExcel(pathToImport);
        showStudentTable(v.findStudent_all1());
    }

    public static void main(String[] args){
       new ImportStudentGUI();
    }
}
