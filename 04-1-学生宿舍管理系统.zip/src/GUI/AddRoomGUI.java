package GUI;

import user.Root;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.sql.ResultSet;
import java.util.Vector;

public class AddRoomGUI {
    JFrame a = new JFrame("新增宿舍");
    JPanel p14 = new JPanel();
    JLabel j1 = new JLabel("宿舍楼ID");
    JLabel j2 = new JLabel("房间号");
    JTextField t1 = new JTextField(20);
    JTextField t2 = new JTextField(20);
    JButton yes = new JButton("确认");
    public static boolean isClosing = false;
    public static boolean isListened = false;
    String[] titleRoom = {"楼号","房间号","备注"};
    String[][] data = {};
    DefaultTableModel defaultTableModel;
    JTable jTable;
    JScrollPane jsp;

    int houseid;
    int roomid;
    public AddRoomGUI(){
        a.setBounds(550, 250, 700, 300);
        a.setVisible(true);
        a.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        p14.setLayout(null);
        a.add(p14);
        j1.setBounds(10,10,60,25);
        j2.setBounds(170,10,40,25);
        t1.setBounds(80,10,80,25);
        t2.setBounds(220,10,80,25);
        yes.setBounds(310,10,80,25);
        p14.add(j1);
        p14.add(j2);
        p14.add(t1);
        p14.add(t2);
        p14.add(yes);
        yes.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                houseid = Integer.parseInt(t1.getText());
                roomid = Integer.parseInt(t2.getText());
                isListened = true;
            }
        });
        a.addWindowListener(new WindowListener(){
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
//                jFrame.dispose();
                isClosing = true;
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });
    }

    public void init(){
        isListened = false;
        isClosing = false;
    }

    public boolean isListened(){
        return isListened;
    }

    public boolean isClosing(){
        return isClosing;
    }

    public void showRoomTable(ResultSet rs){
        defaultTableModel = new DefaultTableModel(data,titleRoom);
        jTable = new JTable(defaultTableModel);
        jTable.setPreferredScrollableViewportSize(new Dimension(550, 100));
        jTable.setRowHeight(20);

        jsp = new JScrollPane(jTable);
        jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        jsp.setBounds(10,50,650,400);
//        System.out.println(jsp.isWheelScrollingEnabled());
        a.add(jsp);

        try{
            while(rs.next()){
                Vector<String> vector = new Vector<String>();
                vector.addElement(rs.getString(1));
                vector.addElement(rs.getString(2));
                vector.addElement(rs.getString(3));
                defaultTableModel.addRow(vector);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void clearTable(){
        defaultTableModel.getDataVector().clear();
        jTable.clearSelection();
        a.remove(jsp);
//        jsp.setColumnHeader(null);
    }

    public void showResult() {
        Root r = new Root();
        r.addRoom(houseid,roomid);
        showRoomTable(r.findRoom_byHouseIDAndRoomID(houseid,roomid));
    }

    public static void main(String[] args){
        new AddRoomGUI();
    }
}
