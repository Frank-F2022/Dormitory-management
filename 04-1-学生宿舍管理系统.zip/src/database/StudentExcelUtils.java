package database;

import entity.Student;
import jxl.*;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;

public class StudentExcelUtils {
    /**
     * 获取指定文件的第一个工作表
     *
     * @param filepath 要读取的文件目录
     * @return 如果文件存在，返回一个工作表，若文件不存在，返回空指针null
     */
    public static Sheet readSheet(String filepath) {
        Sheet sheet = null;
        if (null != filepath && !"".equals(filepath.trim())) {
            Workbook workbook = null;
            InputStream inputStream = null;
            try {
                inputStream = new FileInputStream(filepath);
                workbook = Workbook.getWorkbook(inputStream);
                sheet = workbook.getSheet(0);
                return sheet;
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (null != inputStream) {
                    try {
                        inputStream.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
            }

        }
        return null;
    }

    //测试用的主程序（qwq）
//    public static void main(String[] args) {
////        System.out.println(addStudentsByExcel("G:\\1.xls"));
//        DataBase database = new DataBase();
//        database.dataBase_conn();
//        System.out.println(database.dataBase_getStudentsInOneRoom(new Room(2,101)));
//        database.dataBase_close();
//    }

    /**
     *读取学生信息，返回一个学生的实体列表
     * @param filepath 文件路径
     * @return ArrayList<Student> 一个包含所有学生信息的列表
     */
    public static ArrayList<Student> readStuSheet(String filepath) {
        //要读取的工作表，通过readSheet()获得
        Sheet sheet = readSheet(filepath);
        //判断Sheet是否存在，若为空，返回空指针
        if (sheet == null) return null;

        //循环读取数据，并判断数据有效性，跳过第一行（标题）
        int rows = sheet.getRows(); //读取总行数
        ArrayList<Student> students = new ArrayList<>(); //存放结果数组
        for (int index = 1; index < rows; index++) {
            Student rs = new Student();
            Cell cell;

            int stu_id;         //学生名
            String stu_name;    //姓名
            char sex;           //性别

            String dept;        //学院
            String major;       //专业
            String grade;       //年级
            String phone ;      //电话

            //读入stu_id
            cell = sheet.getCell(0,index);
            if (cell.getType() == CellType.NUMBER) {
                NumberCell num = (NumberCell) cell;
                stu_id = (int) num.getValue();
            } else {
                System.out.println(1);
                continue;
            }

            //读入name
            cell = sheet.getCell(1,index);
                if(cell.getType() == CellType.LABEL){
                    LabelCell name = (LabelCell) cell;
                    stu_name=name.getString();
                } else{
                    continue;
                }


            //读入sex
            cell = sheet.getCell(2,index);
            if(cell.getType() == CellType.LABEL){
                LabelCell nc = (LabelCell) cell;
                sex=nc.getString().charAt(0);
                if(sex!='M' && sex !='F') continue;
            } else{
                continue;
            }

//            读入dept
            cell = sheet.getCell(3,index);
            if(cell.getType() == CellType.LABEL){
                LabelCell nc = (LabelCell) cell;
                dept=nc.getString();
            } else{
                continue;
            }

            //读入major
            cell = sheet.getCell(4,index);
            if(cell.getType() == CellType.LABEL){
                LabelCell nc = (LabelCell) cell;
                major=nc.getString();
            } else{
                continue;
            }

            //读入phone
            cell = sheet.getCell(5,index);
            if(cell.getType() != CellType.EMPTY){
                phone=cell.getContents();
            } else{
                continue;
            }

            //读入grade
            cell = sheet.getCell(6,index);
            if(cell.getType() != CellType.EMPTY){
                grade=cell.getContents();
            } else{
                continue;
            }

            rs.setStuID(stu_id);
            rs.setName(stu_name);
            rs.setSex(sex);
            rs.setDept(dept);
            rs.setMajor(major);
            rs.setPhone(phone);
            rs.setGrade(grade);
            students.add(rs);

        }
        return students;
    }

    /**
     * 从Excel文件读取学生数据并上传至数据库，返回成功操作的值
     * @param filepath 文件目录
     * @return int 成功操作数
     */
    public static int addStudentsByExcel(String filepath){
        int count=0;
        DataBase database = new DataBase();
        database.dataBase_conn();
        ArrayList<Student> students = readStuSheet(filepath);
        if (students != null) {
            for(Student student : students){
                if(database.dataBase_addStudentByStuId(student)){
                    count = count+1;
                }
            }
        }
        database.dataBase_close();
        return count;
    }


}


