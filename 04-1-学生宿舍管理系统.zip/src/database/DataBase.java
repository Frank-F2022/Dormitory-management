package database;

import entity.Building;
import entity.Room;
import entity.Student;
import user.User;

import java.sql.*;
import java.util.ArrayList;

/**
 * 数据库类
 * @author qwq
 * @version 0.0
 *
 */
public class DataBase {

    //数据库基本信息-华为云
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://120.46.33.128:3306/dormitory?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    static final String USER = "remote";
    static final String PASS = "12345678";

    //连接信息
    Connection conn = null;
    Statement stmt = null;


    /**
     * 连接数据库
     * @return boolean 确定连接数据库是否成功
     */
    public boolean dataBase_conn() {
        try {
            // 注册 JDBC 驱动
            Class.forName(JDBC_DRIVER);
            // 打开链接
            System.out.println("正在连接数据库...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("数据库连接成功！");
            //创建实例化对象
            stmt = conn.createStatement();
        } catch (SQLException se) {
            // 处理 JDBC 错误
            se.printStackTrace();
            System.out.println("连接数据库出错！");
            return false;
        } catch (Exception e) {
            // 处理 Class.forName 错误
            e.printStackTrace();
            System.out.println("连接数据库出错！");
            return false;
        }
        return true;
    }


    /**
     * 关闭数据库连接
     * @return boolean 确定关闭数据库连接是否成功
     */
    public boolean dataBase_close() {
        try {
            System.out.println("正在断开数据库连接...");
            stmt.close();
            conn.close();
            System.out.println("数据库连接已断开！");
        } catch (SQLException se) {
            // 处理 JDBC 错误
            se.printStackTrace();
            System.out.println("断开数据库出错！");
            return false;
        } catch (Exception e) {
            // 处理 Class.forName 错误
            e.printStackTrace();
            System.out.println("断开数据库出错！");
            return false;
        }
        return true;
    }


    /**
     * 登陆方法
     * @param userId 用户Id
     * @param passWord 用户口令
     * @return String 确定用户是否登陆成功
     */
    public String dataBase_login(int userId, String passWord) {
        try {
            String sql = "SELECT * FROM Users WHERE id = ? and password = ?";
            PreparedStatement presql = conn.prepareStatement(sql);
            presql.setInt(1,userId);
            presql.setString(2,passWord);
            ResultSet rs = presql.executeQuery();
//            presql.close();
            if(rs.next()) return rs.getString("authority");
        } catch (SQLException e) {
//            e.printStackTrace();
            return "false";
        }
        return "false";
    }


    /**
     * 获取用户信息
     * @param userId 用户Id
     * @return User 返回一个用户对象,出错返回null
     */
    public User dataBase_getUserInfo(int userId) {
        try {
            String sql = "SELECT * FROM Users WHERE id= ?";
            PreparedStatement presql = conn.prepareStatement(sql);
            presql.setInt(1,userId);
            ResultSet rs = presql.executeQuery();
//            presql.close();
            if(rs.next())
                return new User(rs.getInt("id"), rs.getString("name"), rs.getString("authority"));
        } catch (SQLException e) {
//            e.printStackTrace();
            return null;
        }
    return null;
    }


    /**
     * 根据楼号查询宿舍楼信息
     * @param building_id 宿舍楼号
     * @return Building 返回一个宿舍楼对象,包含查询的所有信息
     */
    public Building dataBase_getBuildingInfoById(int building_id) {
        try {
            Building result = null;
            String sql = "SELECT * FROM Buildings where building_id = ?";
            PreparedStatement presql = conn.prepareStatement(sql);
            presql.setInt(1,building_id);
            ResultSet rs = presql.executeQuery();
            if (rs.next()) {
                result = new Building();
                result.setBuilding_id(building_id);
                result.setBuilding_name(rs.getString("building_name"));
                result.setAddress(rs.getString("address"));
                result.setFloors(rs.getInt("floors"));
                result.setMax_students(rs.getInt("max_students"));
                result.setRoom_num(rs.getInt("room_num"));
            }
            return result;
        } catch (SQLException e) {
//            e.printStackTrace();
            return null;
        }
    }


    /**
     * 根据宿舍楼号和房间号查询寝室信息
     * @param building_id 宿舍楼号
     * @param room_id 房间号
     * @return Room 返回一个房间对象，包含所有信息
     */
    public Room dataBase_getRoomInfoById(int building_id, int room_id) {
        try {
            Room result = null;
            String sql = "SELECT * FROM Rooms where building_id = ? and room_id= ?";
            PreparedStatement presql = conn.prepareStatement(sql);
            presql.setInt(1,building_id);
            presql.setInt(2,room_id);
            ResultSet rs = presql.executeQuery();
            if (rs.next()) {
                result = new Room(rs.getInt("building_id"), rs.getInt("room_id"), rs.getString("note"));
            }
            return result;
        } catch (SQLException e) {
//            e.printStackTrace();
            return null;
        }
    }


    /**
     * 根据学生学号查询住宿信息
     * @param stuid 学生学号
     * @return Student 返回一个学生对象（包含所有信息）
     */
    public Student dataBase_getStudentInfoByStuId(int stuid) {
        try {
            Student result = null;
            String sql = "SELECT * FROM Students where stu_id = ?";
            PreparedStatement presql = conn.prepareStatement(sql);
            presql.setInt(1,stuid);
            ResultSet rs = presql.executeQuery();
            if (rs.next()) {
                result = new Student();
                result.setStuID(stuid);
                result.setName(rs.getString("name"));
                result.setSex(rs.getString("Sex").charAt(0));
                result.setGrade(rs.getString("grade"));
                result.setDept(rs.getString("faculty"));
                result.setPhone(rs.getString("phone"));
                result.setMajor(rs.getString("major"));
                //假设不存在住宿信息
                result.setBedID(-1);
                sql = "SELECT * FROM Accommodation where stu_id = ?";
                PreparedStatement presql2 = conn.prepareStatement(sql);
                presql2.setInt(1,stuid);
                rs = presql2.executeQuery();
                if (rs.next()) {
                    result.setBuilding_num(rs.getInt("building_id"));
                    result.setRoom_id(rs.getInt("room_id"));
                    result.setBedID(rs.getInt("bed_id"));
                    result.setInDate(rs.getString("start_date"));
                    result.setOutDate(rs.getString("end_date"));
                }
            }
            return result;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public ResultSet dataBase_getStudentInfoByStuId1(int stuid) {
        try {
            String sql = "SELECT * FROM Students s JOIN Accommodation a ON s.stu_id = a.stu_id WHERE s.stu_id = ?";
            PreparedStatement presql = conn.prepareStatement(sql);
            presql.setInt(1,stuid);
            ResultSet rs = presql.executeQuery();
            if (rs.next()) {
                return rs;
            }else{
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public ResultSet dataBase_getStudentInfoByStuId2(int stuid) {
        try {
            String sql = "SELECT * FROM Accommodation where stu_id = ?";
            PreparedStatement presql = conn.prepareStatement(sql);
            presql.setInt(1,stuid);
            ResultSet rs = presql.executeQuery();
            if (rs.next()) {
                return rs;
            }else{
                return null;
            }
        } catch (SQLException e) {
//            new InvalidSearchGUI();
            e.printStackTrace();
            return null;
        }
    }

    public ResultSet dataBase_getStudentInfoByStuId3(int stuid) {
        try {
            String sql = "SELECT * FROM Students WHERE stu_id = ?";
            PreparedStatement presql = conn.prepareStatement(sql);
            presql.setInt(1,stuid);
            ResultSet rs = presql.executeQuery();
            if (rs.next()) {
                return rs;
            }else{
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }


    /**
     * 根据住宿信息查找学生信息
     * @param building_id 宿舍楼号
     * @param room_id 房间号
     * @param bed_id 床位号
     * @return 返回一个学生对象，包含所有信息
     */
    public Student dataBase_getStudentInfoByAccomodation(int building_id, int room_id, int bed_id) {
        try {
            Student result = null;
            String sql = "SELECT * FROM Accommodation where building_id = ? and room_id= ? and bed_id = ?";
            PreparedStatement presql = conn.prepareStatement(sql);
            presql.setInt(1,building_id);
            presql.setInt(2,room_id);
            presql.setInt(3,bed_id);
            ResultSet rs = presql.executeQuery();
//            presql.close();
            if (rs.next()) {
                result = dataBase_getStudentInfoByStuId(rs.getInt("stu_id"));
            }
            return result;
        } catch (SQLException e) {
//            e.printStackTrace();
            return null;
        }

    }

    public ResultSet dataBase_getStudentInfoByAccomodation1(int building_id, int room_id, int bed_id) {
        try {
//            Student result = null;
            String sql = "SELECT * FROM Accommodation where building_id = ? and room_id= ? and bed_id = ?";
            PreparedStatement presql = conn.prepareStatement(sql);
            presql.setInt(1,building_id);
            presql.setInt(2,room_id);
            presql.setInt(3,bed_id);
            ResultSet rs = presql.executeQuery();
//            presql.close();
            if (rs.next()) {
                return dataBase_getStudentInfoByStuId1(rs.getInt("stu_id"));
            }
            return null;
        } catch (SQLException e) {
//            e.printStackTrace();
            return null;
        }

    }


    /**
     * 删除学生
     * @param stu_id 学号
     * @return boolean 确定是否已正确删除学生对象
     */
    public boolean dataBase_deleteStudentByStuId(int stu_id) {
        try {
            //先删除住宿信息，再删除个人信息
            String sql = "DELETE FROM Accommodation WHERE stu_id = ?";
            PreparedStatement presql1 = conn.prepareStatement(sql);
            presql1.setInt(1,stu_id);
            presql1.executeUpdate();
//            presql1.close();
            sql = "DELETE FROM Students WHERE stu_id = ?";
            PreparedStatement presql2 = conn.prepareStatement(sql);
            presql2.setInt(1,stu_id);
            int rs = presql2.executeUpdate();
//            presql2.close();
            return rs == 1;
        } catch (SQLException e) {
//            e.printStackTrace();
            return false;
        }

    }


    /**
     * 添加学生
     * @param student 学生对象
     * @return boolean 确定是否已正确添加学生对象
     */
    public boolean dataBase_addStudentByStuId(Student student) {
        try {
            if (student == null) return false;
            String sql = "INSERT INTO Students (stu_id,name,Sex,faculty,major,phone,grade) VALUES(?,?,?,?,?,?,?)";
            PreparedStatement presql = conn.prepareStatement(sql);
            presql.setInt(1,student.getStuID());
            presql.setString(2,student.getName());
            presql.setString(3,String.format("%c",student.getSex()));
            presql.setString(4,student.getDept());
            presql.setString(5,student.getMajor());
            presql.setString(6,student.getPhone());
            presql.setString(7,student.getGrade());
            int rs = presql.executeUpdate();
//            presql.close();
            return rs == 1;
        } catch (SQLException e) {
//            e.printStackTrace();
            return false;
        }

    }


    /**
     * 删除宿舍
     * @param building_id 宿舍楼号
     * @param room_id 房间号
     * @return boolean 确定是否已正确删除宿舍对象
     */
    public boolean dataBase_deleteRoomById(int building_id, int room_id) {
        try {
            //先删除学生住宿信息，再删除宿舍信息
            String sql = "DELETE FROM Accommodation WHERE building_id = ? and room_id = ?";
            PreparedStatement presql1 = conn.prepareStatement(sql);
            sql = "DELETE FROM Rooms WHERE building_id = ? and room_id = ?";
            PreparedStatement presql2 = conn.prepareStatement(sql);
            presql1.setInt(1,building_id);
            presql1.setInt(2,room_id);
            presql2.setInt(1,building_id);
            presql2.setInt(2,room_id);
            presql1.executeUpdate();
            int rs = presql2.executeUpdate();
//            presql1.close();
//            presql2.close();
            return rs == 1;
        } catch (SQLException e) {
//            e.printStackTrace();
            return false;
        }

    }


    /**
     * 增加宿舍
     * @param building_id 宿舍楼号
     * @param room_id 房间号
     * @return boolean 确定是否已正确增加宿舍对象
     */
    public boolean dataBase_addRoomById(int building_id, int room_id) {
        try {
            String sql = "INSERT INTO Rooms VALUES (?,?,null)";
            PreparedStatement presql = conn.prepareStatement(sql);
            presql.setInt(1,building_id);
            presql.setInt(2,room_id);
            int rs = presql.executeUpdate();
            return rs == 1;
        } catch (SQLException e) {
//            e.printStackTrace();
            return false;
        }

    }


    /**
     * 删除楼宇
     * @param building_id 宿舍楼号
     * @return boolean 确定是否已正确删除楼宇
     */
    public boolean dataBase_deleteBuildingById(int building_id) {
        try {
            //先删除学生住宿信息，再删除宿舍信息,最后删除楼号
            String sql = "DELETE FROM Accommodation WHERE building_id =?";
            PreparedStatement presql1 = conn.prepareStatement(sql);
            presql1.setInt(1,building_id);
            sql = "DELETE FROM Rooms WHERE building_id =?";
            PreparedStatement presql2 = conn.prepareStatement(sql);
            presql2.setInt(1,building_id);
            sql = "DELETE FROM Buildings WHERE building_id =?";
            PreparedStatement presql3 = conn.prepareStatement(sql);
            presql3.setInt(1,building_id);
            presql1.executeUpdate();
            presql2.executeUpdate();
            int rs =presql3.executeUpdate();
//            presql1.close();
//            presql2.close();
//            presql3.close();
            return rs >= 1;
        } catch (SQLException e) {
//            e.printStackTrace();
            return false;
        }

    }


    /**
     * 增加楼宇
     * @param building 宿舍楼对象
     * @return boolean 确定是否已正确增加楼宇
     */
    public boolean dataBase_addBuildingById(Building building) {
        try {
            if (building == null) return false;
            String sql = "INSERT INTO Buildings VALUES(?,?,?,?,?,?)";
            PreparedStatement presql = conn.prepareStatement(sql);
            presql.setInt(1,building.getBuilding_id());
            presql.setString(2,building.getBuilding_name());
            presql.setString(3,building.getAddress());
            presql.setInt(4,building.getFloors());
            presql.setInt(5,building.getMax_students());
            presql.setInt(6,building.getRoom_num());
            int rs = presql.executeUpdate();
//            presql.close();
            return rs == 1;
        } catch (SQLException e) {
//            e.printStackTrace();
            return false;
        }
    }


    /**
     * 根据学生学号新增住宿信息
     * @param student 学生对象
     * @return boolean 确定是否已正确新增住宿信息
     */
    public boolean dataBase_addAccommodationInfoByStuId(Student student) {
        try {
            if (student == null) return false;
            String sql = "INSERT INTO Accommodation VALUES (?,?,?,?,?,?,null)";
            PreparedStatement presql = conn.prepareStatement(sql);
            presql.setInt(1,student.getStuID());
            presql.setInt(2,student.getBuilding_num());
            presql.setInt(3,student.getRoom_id());
            presql.setInt(4,student.getBedID());
            presql.setString(5,student.getInDate());
            presql.setString(6, student.getOutDate());
            int rs = presql.executeUpdate();
            return rs == 1;
        } catch (SQLException e) {
//            e.printStackTrace();
            return false;
        }

    }


    /**
     * 根据学生学号删除住宿信息
     * @param stu_id 学生学号
     * @return boolean 确定是否已正确删除住宿信息
     */
    public boolean dataBase_deleteAccommpdationByStuId(int stu_id) {
        try {
            String sql = "DELETE FROM Accommodation WHERE stu_id = ? ";
            PreparedStatement presql = conn.prepareStatement(sql);
            presql.setInt(1,stu_id);
            int rs = presql.executeUpdate();
//            presql.close();
            return rs == 1;
        } catch (SQLException e) {
//            e.printStackTrace();
            return false;
        }

    }

    /**
     * 查找所有学生信息
     * @return ArrayList<Student> 返回所有的学生信息
     */
    public ArrayList<Student> dataBase_getAllStudentsInfo(){
        ArrayList<Student> stus = new ArrayList<>();
        try {
            PreparedStatement presql = conn.prepareStatement("SELECT stu_id FROM Students");
            ResultSet rs = presql.executeQuery();
            while(rs.next()){
                stus.add(dataBase_getStudentInfoByStuId(rs.getInt("stu_id")));
            }
            return stus;
        } catch (SQLException e) {
//            throw new RuntimeException(e);
            return null;
        }
    }

    public ResultSet dataBase_getAllStudentsInfo1(){
        try {
            PreparedStatement presql = conn.prepareStatement("SELECT * FROM Students");
            ResultSet rs = presql.executeQuery();
            return rs;
        } catch (SQLException e) {
//            throw new RuntimeException(e);
            return null;
        }
    }

    /**
     * 查找所有宿舍楼信息
     * @return ArrayList<Building> 宿舍楼信息
     */
    public ArrayList<Building> dataBase_getAllBuildingsInfo(){
        ArrayList<Building> buildings = new ArrayList<>();
        try {
            PreparedStatement presql = conn.prepareStatement("SELECT building_id FROM Buildings");
            ResultSet rs = presql.executeQuery();
            while(rs.next()){
                buildings.add(dataBase_getBuildingInfoById(rs.getInt("building_id")));
            }
            return buildings;
        } catch (SQLException e) {
//            throw new RuntimeException(e);
            return null;
        }
    }

    public ResultSet dataBase_getAllBuildingsInfo1(){
        try {
            PreparedStatement presql = conn.prepareStatement("SELECT * FROM Buildings");
            return presql.executeQuery();
        } catch (SQLException e) {
//            throw new RuntimeException(e);
            return null;
        }
    }

    public ResultSet dataBase_getOneBuildingsInfo(int bid){
        try {
            PreparedStatement presql = conn.prepareStatement("SELECT * FROM Buildings WHERE building_id = ?");
            presql.setInt(1,bid);
            return presql.executeQuery();
        } catch (SQLException e) {
//            throw new RuntimeException(e);
            return null;
        }
    }

    /**
     * 查找住在某个房间的所有人
     * @param room 房间信息
     * @return ArrayList<Student> 住在这个房间的所有人的信息
     */
    public ArrayList<Student> dataBase_getStudentsInOneRoom(Room room){
        ArrayList<Student> students = new ArrayList<>();
        try {
            PreparedStatement presql = conn.prepareStatement("SELECT stu_id FROM Accommodation WHERE building_id = ? and room_id = ?");
            presql.setInt(1,room.getBuilding_id());
            presql.setInt(2,room.getRoom_id());
            ResultSet rs =  presql.executeQuery();
            while (rs.next()){
                students.add(dataBase_getStudentInfoByStuId(rs.getInt("stu_id")));
            }
            return students;
        } catch (SQLException e) {
//            throw new RuntimeException(e);
            return null;
        }

    }

    public ResultSet[] dataBase_getStudentsInOneRoom1(Room room){
        try {
            PreparedStatement presql = conn.prepareStatement("SELECT stu_id FROM Accommodation WHERE building_id = ? and room_id = ?");
            presql.setInt(1,room.getBuilding_id());
            presql.setInt(2,room.getRoom_id());
            ResultSet rs =  presql.executeQuery();
            ResultSet[] rsArray =  new ResultSet[4];
            int i = 0;
            while (rs.next()){
                rsArray[i++] = dataBase_getStudentInfoByStuId1(rs.getInt("stu_id"));
            }
            return rsArray;
        } catch (Exception e) {
//            throw new RuntimeException(e);
            return null;
        }

    }
    /**
     * 查找宿舍楼内的所有房间
     * @param building_id 宿舍楼ID
     * @return ArrayList<Room> 宿舍楼内的所有房间的信息
     */
        public ArrayList<Room> dataBase_getRoomsInOneBuilding(int building_id){
        ArrayList<Room> rooms = new ArrayList<>();
        try {
            PreparedStatement presql = conn.prepareStatement("SELECT room_id FROM Rooms WHERE building_id = ?");
            presql.setInt(1, building_id);
            ResultSet rs =  presql.executeQuery();
            while (rs.next()){
                String note;
                try {
                   note = rs.getString("note");
                }catch (Exception e){
                    note="";
                }
                rooms.add(new Room(building_id, rs.getInt("room_id"), note));
            }
            return rooms;
        } catch (SQLException e) {
//            throw new RuntimeException(e);
            e.printStackTrace();
            return null;
        }
    }

    public ResultSet dataBase_getRoomsInOneBuilding1(int building_id) {
        try {
            PreparedStatement presql = conn.prepareStatement("SELECT building_id, room_id, note FROM Rooms WHERE building_id = ?");
            presql.setInt(1, building_id);
            return presql.executeQuery();
        } catch (SQLException e) {
//            throw new RuntimeException(e);
            e.printStackTrace();
            return null;
        }
    }

    public ResultSet dataBase_getRoomsInOneBuilding2(int building_id,int room_id) {
        try {
            PreparedStatement presql = conn.prepareStatement("SELECT building_id, room_id, note FROM Rooms WHERE building_id = ? AND room_id = ?");
            presql.setInt(1, building_id);
            presql.setInt(2, room_id);
            return presql.executeQuery();
        } catch (SQLException e) {
//            throw new RuntimeException(e);
            e.printStackTrace();
            return null;
        }
    }

}

