package service;

import database.*;
import GUI.*;
import user.*;

import java.util.Scanner;

public class UI {
    public static Scanner input = new Scanner(System.in);

    public static DataBase db = new DataBase();

    public UI(){
        while(!db.dataBase_conn()){
            System.out.println("Waiting for re-connection...");
        }
    }

    public static void main(String[] args) {
        UI h = new UI();
        User u = h.Login();

        if (u == null) {
            while(!db.dataBase_close()){
                System.out.println("waiting for closing...");
            }
            System.out.println("System out");
            return;
        }

        while(u != null){
            Viewer v = (Viewer)u;
            if (v instanceof Root) {
                RootGUI rootGUI = new RootGUI();

                while(true){
                    if(rootGUI.isListened()){
                        break;
                    }
                    //增加延时，使程序可以判断循环结束
                    //不加sleep函数会导致循环无法退出
                    h.sleep();
                }

                if(rootGUI.isLogout == true){
                    u = h.Login();
                    if (u == null) {
                        while(!db.dataBase_close()){
                            System.out.println("waiting for closing...");
                        }
                        System.out.println("System out");
                        return;
                    }
                    v = (Viewer)u;
                }else if(rootGUI.isExit == true){
                    while(!db.dataBase_close()){
                        System.out.println("waiting for closing...");
                    }
                    System.out.println("System out");
                    u = null;
                    return;
                }else if(rootGUI.isSearch == true){
                    rootGUI.close();
                    SearchGUI searchGUI = new SearchGUI();
                    while(true){
                        while(true){
                            if(searchGUI.isClosing() || searchGUI.isListened()){
                                break;
                            }
                            h.sleep();
                        }
                        if(!searchGUI.isClosing()){
                            searchGUI.showResult();
                        }else{
                            searchGUI.init();
                            break;
                        }
                        //增加延时，使程序可以判断循环结束
                        //不加sleep函数会导致循环无法退出
                        h.sleep();
                        searchGUI.init();
                        while(true){
                            if(searchGUI.isClosing() || searchGUI.isListened()){
                                break;
                            }
                            h.sleep();
                        }
                        searchGUI.clearTable();
                    }
                }else if(rootGUI.isSwitch == true){
                    rootGUI.close();
                    SwitchStudentGUI switchStudentGUI = new SwitchStudentGUI();
                    while(true){
                        while(true){
                            if(switchStudentGUI.isClosing() || switchStudentGUI.isListened()){
                                break;
                            }
                            h.sleep();
                        }
                        if(!switchStudentGUI.isClosing()){
                            switchStudentGUI.switchStudent();
                        }else{
                            switchStudentGUI.init();
                            break;
                        }
                        //增加延时，使程序可以判断循环结束
                        //不加sleep函数会导致循环无法退出
                        h.sleep();
                        switchStudentGUI.init();
                        while(true){
                            if(switchStudentGUI.isClosing() || switchStudentGUI.isListened()){
                                break;
                            }
                            h.sleep();
                        }
                        switchStudentGUI.clearTable();
                    }
                }else if(rootGUI.isManage == true){
                    rootGUI.close();
                    while(true){
                        ManageGUI manageGUI = new ManageGUI();
                        while(true){
                            if(manageGUI.isClosing() || manageGUI.isListened()){
                                break;
                            }
                            h.sleep();
                        }
                        if(!manageGUI.isClosing()){
                            manageGUI.close();
                            if(manageGUI.isAddStudent == true){
                                AddStudentGUI addStudentGUI = new AddStudentGUI();
                                while(true){
                                    while(true){
                                        if(addStudentGUI.isClosing() || addStudentGUI.isListened()){
                                            break;
                                        }
                                        h.sleep();
                                    }
                                    if(addStudentGUI.isListened()){
//                                        System.out.println("Not closing");
                                        addStudentGUI.showResult();
                                    }else{
                                        addStudentGUI.init();
                                        break;
                                    }
                                    //增加延时，使程序可以判断循环结束
                                    //不加sleep函数会导致循环无法退出
                                    h.sleep();
                                    addStudentGUI.init();
                                    while(true){
                                        if(addStudentGUI.isClosing() || addStudentGUI.isListened()){
                                            break;
                                        }
                                        h.sleep();
                                    }
                                    addStudentGUI.clearTable();
                                }
                            }else if(manageGUI.isDeleteStudent == true){
                                DeleteStudentGUI deleteStudentGUI = new DeleteStudentGUI();
                                while(true){
                                    while(true){
                                        if(deleteStudentGUI.isClosing() || deleteStudentGUI.isListened()){
                                            break;
                                        }
                                        h.sleep();
                                    }
                                    if(deleteStudentGUI.isListened()){
                                        deleteStudentGUI.delete();
                                    }else{
                                        deleteStudentGUI.init();
                                        break;
                                    }
                                    //增加延时，使程序可以判断循环结束
                                    //不加sleep函数会导致循环无法退出
                                    h.sleep();
                                    deleteStudentGUI.init();
                                    while(true){
                                        if(deleteStudentGUI.isClosing() || deleteStudentGUI.isListened()){
                                            break;
                                        }
                                        h.sleep();
                                    }
                                }
                            }else if(manageGUI.isImportStudent == true){
                                ImportStudentGUI importStudentGUI = new ImportStudentGUI();
                                while(true){
                                    while(true){
                                        if(importStudentGUI.isClosing() || importStudentGUI.isListened()){
                                            break;
                                        }
                                        h.sleep();
                                    }
                                    if(importStudentGUI.isListened()){
//                                        System.out.println("Not closing");
                                        importStudentGUI.showResult();
                                    }else{
                                        importStudentGUI.init();
                                        break;
                                    }
                                    //增加延时，使程序可以判断循环结束
                                    //不加sleep函数会导致循环无法退出
                                    h.sleep();
                                    importStudentGUI.init();
                                    while(true){
                                        if(importStudentGUI.isClosing() || importStudentGUI.isListened()){
                                            break;
                                        }
                                        h.sleep();
                                    }
                                    importStudentGUI.clearTable();
                                }
                            }else if(manageGUI.isAddRoom == true){
                                AddRoomGUI addRoomGUI = new AddRoomGUI();
                                while(true){
                                    while(true){
                                        if(addRoomGUI.isClosing() || addRoomGUI.isListened()){
                                            break;
                                        }
                                        h.sleep();
                                    }
                                    if(addRoomGUI.isListened()){
//                                        System.out.println("Not closing");
                                        addRoomGUI.showResult();
                                    }else{
                                        addRoomGUI.init();
                                        break;
                                    }
                                    //增加延时，使程序可以判断循环结束
                                    //不加sleep函数会导致循环无法退出
                                    h.sleep();
                                    addRoomGUI.init();
                                    while(true){
                                        if(addRoomGUI.isClosing() || addRoomGUI.isListened()){
                                            break;
                                        }
                                        h.sleep();
                                    }
                                    addRoomGUI.clearTable();
                                }
                            }else if(manageGUI.isDeleteRoom == true){
                                DeleteRoomGUI deleteRoomGUI = new DeleteRoomGUI();
                                while(true){
                                    while(true){
                                        if(deleteRoomGUI.isClosing() || deleteRoomGUI.isListened()){
                                            break;
                                        }
                                        h.sleep();
                                    }
                                    if(deleteRoomGUI.isListened()){
                                        deleteRoomGUI.delete();
                                    }else{
                                        deleteRoomGUI.init();
                                        break;
                                    }
                                    //增加延时，使程序可以判断循环结束
                                    //不加sleep函数会导致循环无法退出
                                    h.sleep();
                                    deleteRoomGUI.init();
                                    while(true){
                                        if(deleteRoomGUI.isClosing() || deleteRoomGUI.isListened()){
                                            break;
                                        }
                                        h.sleep();
                                    }
                                }
                            }else if(manageGUI.isAddBuilding == true){
                                AddBuildingGUI addBuildingGUI = new AddBuildingGUI();
                                while(true){
                                    while(true){
                                        if(addBuildingGUI.isClosing() || addBuildingGUI.isListened()){
                                            break;
                                        }
                                        h.sleep();
                                    }
                                    if(addBuildingGUI.isListened()){
//                                        System.out.println("Not closing");
                                        addBuildingGUI.showResult();
                                    }else{
                                        addBuildingGUI.init();
                                        break;
                                    }
                                    //增加延时，使程序可以判断循环结束
                                    //不加sleep函数会导致循环无法退出
                                    h.sleep();
                                    addBuildingGUI.init();
                                    while(true){
                                        if(addBuildingGUI.isClosing() || addBuildingGUI.isListened()){
                                            break;
                                        }
                                        h.sleep();
                                    }
                                    addBuildingGUI.clearTable();
                                }
                            }else if(manageGUI.isDeleteBuilding == true){
                                DeleteBuildingGUI deleteBuildingGUI = new DeleteBuildingGUI();
                                while(true){
                                    while(true){
                                        if(deleteBuildingGUI.isClosing() || deleteBuildingGUI.isListened()){
                                            break;
                                        }
                                        h.sleep();
                                    }
                                    if(deleteBuildingGUI.isListened()){
                                        deleteBuildingGUI.delete();
                                    }else{
                                        deleteBuildingGUI.init();
                                        break;
                                    }
                                    //增加延时，使程序可以判断循环结束
                                    //不加sleep函数会导致循环无法退出
                                    h.sleep();
                                    deleteBuildingGUI.init();
                                    while(true){
                                        if(deleteBuildingGUI.isClosing() || deleteBuildingGUI.isListened()){
                                            break;
                                        }
                                        h.sleep();
                                    }
                                }
                            }
                            manageGUI.init();
                        }else{
                            manageGUI.init();
                            break;
                        }
                        //增加延时，使程序可以判断循环结束
                        //不加sleep函数会导致循环无法退出
                        h.sleep();
                        manageGUI.init();
                    }
                }
                rootGUI.init();
            } else {
                ViewerGUI viewerGUI = new ViewerGUI();

                while(true){
                    if(viewerGUI.isListened()){
                        break;
                    }
                    //增加延时，使程序可以判断循环结束
                    //不加sleep函数会导致循环无法退出
                    h.sleep();
                }

                if(viewerGUI.isLogout == true){
                    u = h.Login();
                    if (u == null) {
                        while(!db.dataBase_close()){
                            System.out.println("waiting for closing...");
                        }
                        System.out.println("System out");
                        return;
                    }
                    v = (Viewer)u;
                }else if(viewerGUI.isExit == true){
                    while(!db.dataBase_close()){
                        System.out.println("waiting for closing...");
                    }
                    System.out.println("System out");
                    u = null;
                    return;
                }else if(viewerGUI.isSearch == true){
                    viewerGUI.close();
                    SearchGUI searchGUI = new SearchGUI();
                    while(true){
                        while(true){
                            if(searchGUI.isClosing() || searchGUI.isListened()){
                                break;
                            }
                            h.sleep();
                        }
                        if(!searchGUI.isClosing()){
                            searchGUI.showResult();
                        }else{
                            searchGUI.init();
                            break;
                        }
                        //增加延时，使程序可以判断循环结束
                        //不加sleep函数会导致循环无法退出
                        h.sleep();
                        searchGUI.init();
                        while(true){
                            if(searchGUI.isClosing() || searchGUI.isListened()){
                                break;
                            }
                            h.sleep();
                        }
                        searchGUI.clearTable();
                    }
                }else if(viewerGUI.isSwitch == true){
                    viewerGUI.close();
                    SwitchStudentGUI switchStudentGUI = new SwitchStudentGUI();
                    while(true){
                        while(true){
                            if(switchStudentGUI.isClosing() || switchStudentGUI.isListened()){
                                break;
                            }
                            h.sleep();
                        }
                        if(!switchStudentGUI.isClosing()){
                            switchStudentGUI.switchStudent();
                        }else{
                            switchStudentGUI.init();
                            break;
                        }
                        //增加延时，使程序可以判断循环结束
                        //不加sleep函数会导致循环无法退出
                        h.sleep();
                        switchStudentGUI.init();
                        while(true){
                            if(switchStudentGUI.isClosing() || switchStudentGUI.isListened()){
                                break;
                            }
                            h.sleep();
                        }
                        switchStudentGUI.clearTable();
                    }
                }
                viewerGUI.init();
            }
        }
    }




    public User Login(){
        LoginGUI loginGUI = new LoginGUI();
        while(true){
            if(loginGUI.isLogin()){
                String authority = db.dataBase_login(loginGUI.userTextInput, loginGUI.passwordTextInput);
                if (!authority.equals("false") ) {
                    User u = db.dataBase_getUserInfo(loginGUI.userTextInput);
                    if(u == null) {
                        System.out.println("login failed, retrying...");
                        continue;
                    }
                    System.out.println("Welcome!");
                    System.out.println(u);
                    User uu = null;
                    if(authority.equals("root")){
                        uu = new Root(u.getUserID(), u.getUserName(), u.getUserAuthority());
                    }else{
                        uu = new Viewer(u.getUserID(), u.getUserName(), u.getUserAuthority());
                    }
                    System.out.println("login successfully");
                    loginGUI.LoginGUIClose();
                    return uu;
                } else {
                    new LoginFailedGUI();
                }
            }
        }
    }

    public static int getChoice(int min, int max) {
        int choice = -1;
        while (true) {
            if (input.hasNextInt()) {
                choice = input.nextInt();
                if (choice >= min && choice <= max) {
                    break;
                }
            }
            System.out.println("请输入正确数字");
            input.nextLine();
        }
        return choice;
    }

    public static boolean getYN() {
        while (true) {
            System.out.print(" （Y/N）：");
            String min = input.next();
            Character choice = min.charAt(0);
            if (choice.equals('Y') || choice.equals('y'))
                return true;
            else if (choice.equals('N') || choice.equals('n'))
                return false;
            System.out.println("wrong choice");
        }
    }

    public void sleep(){
        try{
            Thread.sleep(100);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
