package entity;

public class Student {
    private int stuID;          //学生编号
    private String name;        //姓名
    private char sex;           //性别

    private String dept;        //学院
    private String major;       //专业
    private String grade;       //年级
    private String phone;       //电话

    private int building_num;   //宿舍楼号
    private int room_id;        //宿舍房间号
    private int bedID;          //宿舍床号
    private String inDate;      //住宿日期
    private String outDate;     //离开日期

    public void setStuID(int stuID) {
        this.stuID = stuID;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSex(char sex) {
        this.sex = sex;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setBuilding_num(int building_num) {
        this.building_num = building_num;
    }

    public void setRoom_id(int room_id) {
        this.room_id = room_id;
    }

    public void setBedID(int bedID) {
        this.bedID = bedID;
    }

    public void setInDate(String inDate) {
        this.inDate = inDate;
    }

    public void setOutDate(String outDate) {
        this.outDate = outDate;
    }

    public Student(int stuID, String name, char sex, String dept, String major, String grade, String phone) {
        this.stuID = stuID;
        this.name = name;
        this.sex = sex;
        this.dept = dept;
        this.major = major;
        this.grade = grade;
        this.phone = phone;
    }

    public Student() {
        return;
    }

    public int getStuID() {
        return stuID;
    }

    public String getName() {
        return name;
    }

    public char getSex() {
        return sex;
    }

    public String getDept() {
        return dept;
    }

    public String getMajor() {
        return major;
    }

    public String getGrade() {
        return grade;
    }

    public String getPhone() {
        return phone;
    }

    public int getBuilding_num() {
        return building_num;
    }

    public int getRoom_id() {
        return room_id;
    }

    public int getBedID() {
        return bedID;
    }

    public String getInDate() {
        return inDate;
    }

    public String getOutDate() {
        return outDate;
    }

    @Override
    public String toString() {
        return "Student{" +
                "stuID=" + stuID +
                ", name='" + name + '\'' +
                ", sex=" + sex +
                ", dept='" + dept + '\'' +
                ", major='" + major + '\'' +
                ", grade='" + grade + '\'' +
                ", phone='" + phone + '\'' +
                ", building_num=" + building_num +
                ", room_id=" + room_id +
                ", bedID=" + bedID +
                ", inDate='" + inDate + '\'' +
                ", outDate='" + outDate + '\'' +
                '}';
    }
}
