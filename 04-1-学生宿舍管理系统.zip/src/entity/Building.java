package entity;

public class Building {
    int building_id;
    String building_name;
    String address;
    int floors;
    int max_students;
    int room_num;

    public void setBuilding_id(int building_id) {
        this.building_id = building_id;
    }

    public void setBuilding_name(String building_name) {
        this.building_name = building_name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setFloors(int floors) {
        this.floors = floors;
    }

    public void setMax_students(int max_students) {
        this.max_students = max_students;
    }

    public void setRoom_num(int room_num) {
        this.room_num = room_num;
    }

    public int getBuilding_id() {
        return building_id;
    }

    public String getBuilding_name() {
        return building_name;
    }

    public String getAddress() {
        return address;
    }

    public int getFloors() {
        return floors;
    }

    public int getMax_students() {
        return max_students;
    }

    public int getRoom_num() {
        return room_num;
    }

    public Building(int building_id, String building_name, String address, int floors, int max_students, int room_num) {

        this.building_id = building_id;
        this.building_name = building_name;
        this.address = address;
        this.floors = floors;
        this.max_students = max_students;
        this.room_num = room_num;
    }

    public Building() {
    }

    @Override
    public String toString() {
        return "Building{" +
                "building_id=" + building_id +
                ", building_name='" + building_name + '\'' +
                ", address='" + address + '\'' +
                ", floors=" + floors +
                ", max_students=" + max_students +
                ", room_num=" + room_num +
                '}';
    }
}
