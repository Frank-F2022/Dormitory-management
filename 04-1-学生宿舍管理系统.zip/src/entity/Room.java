package entity;

public class Room {
    int building_id;
    int room_id;
    String note;

    public Building building = null;

    public void setBuilding_id(int building_id) {
        this.building_id = building_id;
    }

    public void setRoom_id(int room_id) {
        this.room_id = room_id;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Room(int building_id, int room_id) {
        this.building_id = building_id;
        this.room_id = room_id;
    }

    public int getBuilding_id() {
        return building_id;
    }

    public int getRoom_id() {
        return room_id;
    }

    public String getNote() {
        return note;
    }

    public Room(int building_id, int room_id, String note) {
        this.building_id = building_id;
        this.room_id = room_id;
        this.note = note;
    }

    @Override
    public String toString() {
        return "Room{" +
                "building_id=" + building_id +
                ", room_id=" + room_id +
                ", note='" + note + '\'' +
                '}';
    }
}
