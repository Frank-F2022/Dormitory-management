package user;

import entity.Building;
import entity.Room;
import entity.Student;
import GUI.AddStudentFailedGUI;
import service.UI;
import GUI.*;

public class Root extends Viewer{

    int stuID;
    String stuName;
    char sex;
    String dept;
    String major;
    String grade;
    String phone;

    int roomID;
    int houseID;
    String houseName;
    String address;
    int floors;
    int max_students;
    int room_num;

    Student stu;
    Room room;
    Building building;


    public Root(){}
    public Root(int ID, String name, String userAuthority) {
        super(ID, name, userAuthority);
    }

    public void Manage(){
        while (true) {
            System.out.print("\n1.学生信息管理 2.房间管理 3.宿舍楼管理 4.返回\nplease input:");
            int choice = UI.getChoice(1, 4);
            switch (choice) {
                case 1 -> this.stuInfoManage();
                case 2 -> this.roomInfoManage();
                case 3 -> this.buildingInfoManage();
                case 4 -> {
                    return;
                }
            }
        }
    }

    public void stuInfoManage(){
         while (true) {
            System.out.print("\n1.新增学生 2.修改学生 3.删除学生 4.返回\nplease input:");
            int choice = UI.getChoice(1, 4);
            switch (choice) {
//                case 1 -> this.addStu();
//                case 2 -> this.changeStu();
//                case 3 -> this.deleteStu();
                case 4 -> {
                    return;
                }
            }
        }
    }

    public void addStu(int stuID, String stuName, char sex, String dept, String major, String grade, String phone){
        stu = new Student(stuID, stuName, sex, dept, major, grade, phone);
        if(UI.db.dataBase_addStudentByStuId(stu)){
            System.out.println("Student added successfully");
        }else{
            new AddStudentFailedGUI();
            System.out.println("Student add failed");
        }
    }

    public void deleteStu(int stuID){
        if(UI.db.dataBase_deleteStudentByStuId(stuID)){
            System.out.println("Student deleted successfully");
            new DeleteStudentSucceededGUI();
        }else{
            System.out.println("Student delete failed");
            new DeleteStudentFailedGUI();
        }
    }

    public void roomInfoManage(){
         while (true) {
            System.out.print("\n1.新增房间 2.修改房间 3.删除房间 4.返回\nplease input:");
            int choice = UI.getChoice(1, 4);
            switch (choice) {
//                case 1 -> this.addRoom();
//                case 2 -> this.changeRoom();
//                case 3 -> this.deleteRoom();
                case 4 -> {
                    return;
                }
            }
        }

    }

    public void addRoom(int houseID, int roomID){
        if(UI.db.dataBase_addRoomById(houseID, roomID)){
            System.out.println("room added successfully");
        }else{
            System.out.println("room added failed");
            new AddRoomFailedGUI();
        }
    }

    public void deleteRoom(int houseID, int roomID){
        if(UI.db.dataBase_deleteRoomById(houseID, roomID)){
            System.out.println("room deleted successfully");
            new DeleteRoomSucceededGUI();
        }else{
            System.out.println("room delete failed");
            new DeleteRoomFailedGUI();
        }
    }



    public void buildingInfoManage(){
         while (true) {
            System.out.print("\n1.新增宿舍楼 2.修改宿舍楼 3.删除宿舍楼 4.返回\nplease input:");
            int choice = UI.getChoice(1, 4);
            switch (choice) {
//                case 1 -> this.addBuilding();
//                case 2 -> this.changeBuilding();
//                case 3 -> this.deleteBuilding();
                case 4 -> {
                    return;
                }
            }
        }

    }

    public void addBuilding(int houseID, String houseName, String address, int floors, int max_students, int room_num){
        building = new Building(houseID, houseName, address, floors, max_students, room_num);
        if(UI.db.dataBase_addBuildingById(building)){
            System.out.println("Building added successfully");
        }else{
            new AddBuildingFailedGUI();
            System.out.println("Building add failed");
        }
    }

    public void deleteBuilding(int houseID){
        if(UI.db.dataBase_deleteBuildingById(houseID)){
            new DeleteBuildingSucceededGUI();
            System.out.println("Building deleted successfully");
        }else{
            new DeleteBuildingFailedGUI();
            System.out.println("Building delete failed");
        }
    }

    
}
