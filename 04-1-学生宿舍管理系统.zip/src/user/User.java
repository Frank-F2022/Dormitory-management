package user;

public class User {
    private int userID;
    private String userName;
    private String userAuthority;
//    private String userPassword;
    public User(){
        ;
    }


    public User(int ID, String name, String userAuthority){
        this.userID =  ID;
        this.userName = name;
        this.userAuthority = userAuthority;
    }

    public String toString(){
        return "UserID:"+userID+"\nuserName:"+userName+"\nuserAuthority:"+userAuthority+"\n";
    }
    public int getUserID() {
        return userID;
    }

    public String getUserName() {
        return userName;
    }

    public String getUserAuthority() {
        return userAuthority;
    }


    //    public static void main(String[] args) throws SQLException {
//        User user;
//        DataBase a = new DataBase();
//        a.dataBase_conn();
//       if(a.dataBase_login(1,"123456").equals("root")){
//           user = a.dataBase_getUserInfo(1);
//           System.out.println("登陆成功，欢迎"+user.userName+"，当前权限组为"+user.userAuthority);
////           Student b = a.dataBase_getStudentInfoByAccomodation(1,101,4);
////           if(b !=null) System.out.println(b);
////           Building c = a.dataBase_getBuildingInfoById(1);
////           System.out.println(c);
////           Room d = a.dataBase_getRoomInfoById(8,501);
////           System.out.println(d);
////           System.out.println(a.dataBase_deleteStudentByStuId(15));
////           System.out.println(a.dataBase_deleteBuildingById(10));
////           Student stu = new Student(212261,"sth",'M',"微电子学院","电子科学与技术","2021","110");
////           a.dataBase_addStudentByStuId(stu);
////           Student sth = a.dataBase_getStudentInfoByStuId(212261);
////           System.out.println(sth);
////            Building building =new Building(11,"开发区新楼","开发区校区",15,2000,500);
//            Student test = new Student();
//            test.setStuID(212261);
//            test.setBuilding_num(1);
//            test.setRoom_id(101);
//            test.setBedID(4);
//            a.dataBase_addAccommodationInfoByStuId(test);
//           System.out.println(a.dataBase_getStudentInfoByStuId(212261));
////           a.dataBase_deleteRoomById(1,101);
//       }
//       else{
//           System.out.println("账号或密码错误，登录失败！");
//       }
//        a.dataBase_close();
//    }
}
