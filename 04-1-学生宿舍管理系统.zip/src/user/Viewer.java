package user;
import entity.Building;
import entity.Room;
import entity.Student;
import service.UI;

import java.sql.ResultSet;
import java.util.ArrayList;

public class Viewer extends User{
    public Viewer(int ID, String name, String userAuthority) {
        super(ID, name, userAuthority);
    }

    ArrayList<Building> buildings;
    int houseID;
    int roomID;
    int bedID;
    Student stu;
    Student stu2;
Room room;
ArrayList<Room> rooms;
    int stuID;
    ArrayList<Student> s;

    public Viewer() {
        super();
    }

    public void Check(){
        while (true) {
            System.out.print("\n1.根据宿舍查看学生 2.根据学生ID查看信息 3.查看所有学生 4.查看宿舍人员 5.根据楼ID查看宿舍 6.查看所有宿舍楼 7.返回\nplease input:");
            int choice = UI.getChoice(1, 7);
            switch (choice) {
                case 1 -> this.findStudent_byRoom();
                case 2 -> this.findRoom_byStudentID();
                case 3 -> this.findStudent_all();
                case 4 -> this.findRoom_Student();
                case 5 -> this.findRoom_byHouseID();
                case 6 -> this.findBuilding_all();
                case 7 -> {
                    return;
                }
            }
        }
    }
    public void findStudent_byRoom() {
        System.out.print("input HouseID: ");
        houseID = UI.getChoice(1, 999999999);
        System.out.print("input roomID: ");
        roomID = UI.getChoice(1, 999999999);
        System.out.print("input bedID: ");
        bedID = UI.getChoice(1, 4);
        stu =  UI.db.dataBase_getStudentInfoByAccomodation(houseID, roomID, bedID);
        if(stu == null){
            System.out.println("Student not found");
            return;
        }
        System.out.println(stu);


    }

    public ResultSet findStudent_byRoom1(int houseID, int roomID, int bedID) {
//        this.houseID = houseID;
//        this.roomID = roomID;
//        this.bedID = bedID;
        ResultSet rs = UI.db.dataBase_getStudentInfoByAccomodation1(houseID, roomID, bedID);
        if(rs == null){
            System.out.println("Student not found");
            return null;
        }
//        System.out.println(stu);
        return rs;
    }

    public void findRoom_byStudentID(){
        System.out.print("input StudentID:");
        stuID = UI.getChoice(1, 999999999);
        stu =  UI.db.dataBase_getStudentInfoByStuId(stuID);
        if(stu == null){
            System.out.println("Student not found");
            return;
        }
        System.out.println(stu);
    }

    public ResultSet findRoom_byStudentID1(int sID){
        ResultSet rs = UI.db.dataBase_getStudentInfoByStuId1(sID);
        if(rs == null){
            System.out.println("Student not found");
            return null;
        }
        return rs;
    }

    public ResultSet findRoom_byStudentID2(int sID){
        ResultSet rs = UI.db.dataBase_getStudentInfoByStuId2(sID);
        if(rs == null){
            System.out.println("Student not found");
            return null;
        }
        return rs;
    }

    public ResultSet findRoom_byStudentID3(int sID){
        ResultSet rs = UI.db.dataBase_getStudentInfoByStuId1(sID);
        if(rs == null){
            System.out.println("Student not found");
            return null;
        }
        return rs;
    }

    public void findStudent_all(){
        s = UI.db.dataBase_getAllStudentsInfo();
        if(s == null){
            System.out.println("No students found");
            return;
        }
        for (Student student : s) {
            System.out.println(student);
        }
    }

    public ResultSet findStudent_all1(){
        ResultSet rs = UI.db.dataBase_getAllStudentsInfo1();
        if(rs == null){
            System.out.println("No students found");
            return null;
        }
        return rs;
    }

    public void findRoom_Student(){
        System.out.print("input HouseID: ");
        houseID = UI.getChoice(1, 999999999);
        System.out.print("input roomID: ");
        roomID = UI.getChoice(1, 999999999);
        room = new Room(houseID, roomID);
        s = UI.db.dataBase_getStudentsInOneRoom(room);
        if(s == null){
            System.out.println("No students found");
            return;
        }
        for (Student student : s) {
            System.out.println(student);
        }
    }

    public ResultSet[] findRoom_Student1(int houseID, int roomID){
        room = new Room(houseID, roomID);
        return UI.db.dataBase_getStudentsInOneRoom1(room);
    }

    public void findRoom_byHouseID(){
        System.out.print("input HouseID: ");
        houseID = UI.getChoice(1, 999999999);
        rooms = UI.db.dataBase_getRoomsInOneBuilding(houseID);
        if(rooms == null){
            System.out.println("No rooms found");
            return;
        }
        for(Room room: rooms){
            System.out.println(room);
        }
    }

    public ResultSet findRoom_byHouseID1(int houseID){
        return UI.db.dataBase_getRoomsInOneBuilding1(houseID);
    }

    public ResultSet findRoom_byHouseIDAndRoomID(int houseID,int roomID){
        return UI.db.dataBase_getRoomsInOneBuilding2(houseID,roomID);
    }

    public void findBuilding_all(){
        buildings = UI.db.dataBase_getAllBuildingsInfo();
        if(buildings == null){
            System.out.println("No buildings found");
            return;
        }
        for(Building building: buildings){
            System.out.println(building);
        }
    }

    public ResultSet findBuilding_all1(){
        return UI.db.dataBase_getAllBuildingsInfo1();
    }

    public ResultSet findBuilding_byBuildingID(int bid){
        return UI.db.dataBase_getOneBuildingsInfo(bid);
    }

    public void change(){
        while (true) {
            System.out.print("\n1.新增/调换住宿信息 2.删除住宿信息 3.返回\nplease input:");
            int choice = UI.getChoice(1, 3);
//            switch (choice) {
//                case 1 -> this.addAccommodation();
//                case 2 -> this.removeAccommodation();
//                case 3 -> this.exchangeAccommodation();
//                case 3 -> {
//                    return;
//                }
//            }
        }
    }


    public void removeAccommodation(){
        System.out.print("input StudentID:");
        stuID = UI.getChoice(1, 999999999);
        stu =  UI.db.dataBase_getStudentInfoByStuId(stuID);
        if(stu == null){
            System.out.println("Student not found");
            return;
        }
        System.out.println(stu);
        System.out.print("Confirm to remove Accommodation(Y/N):");
        if(UI.getYN()){
            if(UI.db.dataBase_deleteAccommpdationByStuId(stuID))
                System.out.println("Accommodation successfully removed");
            else{
                System.out.println("Accommodation remove failed");
            }
        }

    }

    public void addAccommodation(int stuID, int houseID, int roomID, int bedID){
        stu = UI.db.dataBase_getStudentInfoByStuId(stuID);
        if(stu == null){
            System.out.println("Student not found");
            return;
        }
        stu2 = UI.db.dataBase_getStudentInfoByAccomodation(houseID, roomID, bedID);
        if(stu2 == null){
            if(stu.getBedID()!=0 && stu.getBedID()!=-1){
                if(UI.db.dataBase_deleteAccommpdationByStuId(stuID)){
                    System.out.println("Student successfully removed");
                }else{
                    System.out.println("Student remove failed");
                    return;
                }
            }
            stu.setBuilding_num(houseID);
            stu.setRoom_id(roomID);
            stu.setBedID(bedID);
            stu.setInDate("2021-9-1");
            if(UI.db.dataBase_addAccommodationInfoByStuId(stu)){
                System.out.println("Student successfully added");
            }else{
                System.out.println("Student add failed");
                return;
            }
        }else if(stu2.equals(stu)){
            System.out.print("same student allocated");
            return;
        }else{
            System.out.print("position allocated");
            System.out.println(stu2);
            return;
        }
    }

}
